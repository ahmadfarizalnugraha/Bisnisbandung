<?php defined('ROOT') || die() ?>

<?php Security::csrf_set_session_token('url_token') ?>

<div class="d-flex justify-content-around row">
    <div class="col-12 col-md-5 mb-5">
        <div class="card zoomer border-0 p-2">
            <div class="card-body text-center">

                <div class="pricing-card-header-text text-main mb-4"><?= $language->pro->display->free_account ?></div>

                <div class="mb-4">
                    <span class="pricing-card-price text-dark"><?= $language->pro->display->free_account_pricing ?></span>

                    <span class="pricing-card-price-currency">

                    </span>
                </div>

                <div class="mb-5">
                    <div class="text-muted mb-5"><strong><?= $language->pro->free->zero ?></strong></div>

                    <span class="text-muted"><?= $language->pro->free->one ?></span>

                    <hr />
                    <span class="text-muted"><?= $language->pro->free->two ?></span>

                    <?php if($settings->user_links_limit > 0): ?>
                        <hr />
                        <span class="text-muted"><?= sprintf($language->pro->free->user_links_limit, $settings->user_links_limit) ?></span>
                    <?php endif ?>

                    <?php if(!$settings->store_pro_features_verified): ?>
                        <hr />
                        <span class="text-muted"><i class="fa fa-check"></i> <?= $language->pro->pro->verified ?></span>
                    <?php endif ?>

                    <?php if(!$settings->store_pro_features_colored): ?>
                        <hr />
                        <span class="text-muted"><i class="fa fa-paint-brush"></i> <?= $language->pro->pro->colored ?></span>
                    <?php endif ?>

                    <?php if(!$settings->store_pro_features_fb_pixel): ?>
                        <hr />
                        <span class="text-muted"><i class="fa fa-infinity"></i> <?= $language->pro->pro->fb_pixel ?></span>
                    <?php endif ?>

                    <?php if(!$settings->store_pro_features_bitly): ?>
                        <hr />
                        <span class="text-muted"><img src="template/images/bitly.svg" class="bitly-logo m-0" /> <?= $language->pro->pro->bitly ?></span>
                    <?php endif ?>

                    <?php if(!$settings->store_pro_features_background): ?>
                        <hr />
                        <span class="text-muted"><i class="fa fa-fill-drip"></i> <?= $language->pro->pro->background ?></span>
                    <?php endif ?>

                    <?php if(!$settings->store_pro_features_ga): ?>
                        <hr />
                        <span class="text-muted"><i class="fab fa-google"></i> <?= $language->pro->pro->ga ?></span>
                    <?php endif ?>

                    <?php if(!$settings->store_pro_features_schedule): ?>
                        <hr />
                        <span class="text-muted"><i class="fa fa-clock"></i> <?= $language->pro->pro->schedule ?></span>
                    <?php endif ?>
                </div>

                <?php if(!User::logged_in()): ?>
                    <a href="register" class="btn btn-primary bg-main border-0"><?= $language->pro->display->register ?></a>
                <?php endif ?>
            </div>
        </div>
    </div>

    <div class="col-12 col-md-5">
        <div class="card zoomer border-0 p-2 pricing-card-pro">
            <div class="card-body text-center">

                <div class="pricing-card-header-text text-main mb-4"><?= $language->pro->display->pro_account ?></div>

                <div class="mb-4">
                    <span class="pricing-card-price text-white"><?= $settings->store_pro_price_month ?></span>

                    <span class="pricing-card-price-currency text-white">
                        <?= $settings->store_currency ?>
                    </span>
                </div>

                <div class="mb-5">
                    <div class="text-white-50 mb-5"><strong><?= $language->pro->pro->zero ?></strong></div>

                    <span class="text-light"><i class="fa fa-ad"></i> <?= $language->pro->pro->no_ads ?></span>

                    <hr />
                    <span class="text-light"><i class="fa fa-ad"></i> <?= $language->pro->pro->no_trademark ?></span>

                    <?php if($settings->store_pro_features_verified): ?>
                        <hr />
                        <span class="text-light"><i class="fa fa-check"></i> <?= $language->pro->pro->verified ?></span>
                    <?php endif ?>

                    <?php if($settings->store_pro_features_colored): ?>
                        <hr />
                        <span class="text-light"><i class="fa fa-paint-brush"></i> <?= $language->pro->pro->colored ?></span>
                    <?php endif ?>

                    <?php if($settings->user_links_limit > 0): ?>
                        <hr />
                        <span class="text-light"><i class="fa fa-infinity"></i> <?= $language->pro->pro->user_links_limit ?></span>
                    <?php endif ?>

                    <?php if($settings->store_pro_features_fb_pixel): ?>
                        <hr />
                        <span class="text-light"><i class="fab fa-facebook"></i> <?= $language->pro->pro->fb_pixel ?></span>
                    <?php endif ?>

                    <?php if($settings->store_pro_features_bitly): ?>
                        <hr />
                        <span class="text-light"><img src="template/images/bitly.svg" class="bitly-logo m-0" /> <?= $language->pro->pro->bitly ?></span>
                    <?php endif ?>

                    <?php if($settings->store_pro_features_background): ?>
                        <hr />
                        <span class="text-light"><i class="fa fa-fill-drip"></i> <?= $language->pro->pro->background ?></span>
                    <?php endif ?>

                    <?php if($settings->store_pro_features_ga): ?>
                        <hr />
                        <span class="text-light"><i class="fab fa-google"></i> <?= $language->pro->pro->ga ?></span>
                    <?php endif ?>

                    <?php if($settings->store_pro_features_schedule): ?>
                        <hr />
                        <span class="text-light"><i class="fa fa-clock"></i> <?= $language->pro->pro->schedule ?></span>
                    <?php endif ?>
                </div>


                <?php if(!User::logged_in() || (User::logged_in() && !$account->pro)): ?>

                    <?php if($settings->store_pro_trial > 0 && (!User::logged_in() || User::logged_in() && !$account->pro_trial_done)): ?>
                        <a href="<?= User::logged_in() ? 'store/purchase/trial/' . Security::csrf_get_session_token('url_token') : 'register' ?>" class="btn btn-dark bg-main btn-block border-0 mb-3"><?= sprintf($language->pro->display->trial, $settings->store_pro_trial) ?></a>
                    <?php endif ?>

                    <div class="d-flex justify-content-around">
                        <div class="input-group">
                            <select id="purchase_package" class="custom-select border-0">
                                <option value="month" selected>
                                    <?= sprintf($language->pro->prices->monthly, $settings->store_currency . ' ' . $settings->store_pro_price_month) ?>
                                </option>
                                <option value="year">
                                    <?= sprintf($language->pro->prices->yearly, $settings->store_currency . ' ' . $settings->store_pro_price_year) ?>
                                </option>
                            </select>

                            <div class="input-group-append">
                                <?php if(User::logged_in()): ?>
                                    <a href="" id="purchase_link" data-confirm="<?= $language->store->confirm_purchase ?>" class="btn btn-light border-0 bg-white"><i class="fa fa-unlock-alt"></i> <?= $language->pro->display->purchase ?></a>
                                <?php else: ?>
                                    <a href="register" class="btn btn-light border-0"><?= $language->pro->display->register ?></a>
                                <?php endif ?>
                            </div>
                        </div>
                    </div>
                <?php endif ?>

            </div>
        </div>
    </div>

</div>

<script>
    $(document).ready(() => {
        let update_purchase_link = () => {
            let purchase_package = $('#purchase_package').find(':selected').val();
            let purchase_link = 'store/purchase/'+purchase_package+'/'+`<?= Security::csrf_get_session_token('url_token') ?>`;

            $('#purchase_link').attr('href', purchase_link);
        };

        update_purchase_link();

        $('#purchase_package').on('change', update_purchase_link);
    })
</script>
