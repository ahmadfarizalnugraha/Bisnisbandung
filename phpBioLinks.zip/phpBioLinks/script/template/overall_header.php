<?php defined('ROOT') || die() ?>

<!DOCTYPE html>
<html class="<?= $language->direction ?>" dir="<?= $language->direction ?>">
	<?php include 'includes/head.php' ?>

    <body <?php if(in_array($page, $full_white_pages)) echo 'class="bg-white"' ?>>

		<?php include 'includes/menu.php' ?>

        <?php if($page !== 'index'): ?>
            <div class="container animated fadeIn"><!-- Start Container -->

            <?php display_notifications() ?>
        <?php endif ?>

        <?php if(!empty($settings->top_ads) && ((User::logged_in() && !$account->pro) || !User::logged_in())): ?>
            <div class="container">
                <div class="my-3">
                    <?= $settings->top_ads ?>
                </div>
            </div>
        <?php endif ?>
