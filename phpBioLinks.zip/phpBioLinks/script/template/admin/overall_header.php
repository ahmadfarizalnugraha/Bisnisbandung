<!DOCTYPE html>
<html class="<?= $language->direction ?>" dir="<?= $language->direction ?>">
	<?php include 'template/admin/includes/head.php' ?>

	<body>

		<?php include 'template/admin/includes/menu.php' ?>

		<div class="container animated fadeIn ">

		<?php display_notifications() ?>
