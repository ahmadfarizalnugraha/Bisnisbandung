            <hr />

            <div class="mb-5">
                <span class="text-muted"><?= 'Copyright &copy; ' . date('Y') . ' ' . $settings->title . '. All rights reserved. Product by <a href="https://codecanyon.net/user/altumcode">AltumCode</a>' ?></span>
            </div>

        </div>
    </body>
</html>
