<?php defined('ROOT') || die() ?>

            <?php if(!empty($settings->bottom_ads) && ((User::logged_in() && !$account->pro) || !User::logged_in())): ?>
                <div class="container">
                    <div class="my-3">
                        <?= $settings->bottom_ads ?>
                    </div>
                </div>
            <?php endif ?>

        <?php if($page !== 'index'): ?>
        </div><!-- END Container -->
        <?php endif ?>

        <?php include 'includes/footer.php' ?>


		<?php if($page == 'dashboard'): ?>

			<div class="modal fade" id="edit_link" tabindex="-1" role="dialog" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<form action="dashboard" method="post" role="form">
                            <input type="hidden" name="form_token" value="<?= Security::csrf_get_session_token('form_token') ?>" />

                            <div class="modal-header">
								<h5 class="modal-title"><?= $language->dashboard->edit_link_modal->header ?></h5>

								<button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								</button>
							</div>

							<div class="modal-body">
								<input type="hidden" class="form-control" name="link_id" value="" />

								<div class="form-group">
									<input type="text" class="form-control" name="title" placeholder="<?= $language->dashboard->input->title_placeholder ?>">
								</div>
								<div class="form-group">
									<input type="text" class="form-control" name="url" placeholder="<?= $language->dashboard->input->url_placeholder ?>">
								</div>

								<?php if(($settings->store_pro_features_colored && $account->pro) || !$settings->store_pro_features_colored): ?>
                                <div class="color_button"><div></div></div>

                                <div class="form-group">
                                    <input type="hidden" name="color" value="#000000" />
                                </div>
			                    <?php endif ?>

                                <?php if(!empty($account->bitly_token) && (($settings->store_pro_features_bitly && $account->pro) || !$settings->store_pro_features_bitly)): ?>
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" id="bitly_modal" name="bitly">
                                        <label class="custom-control-label" for="bitly_modal"><img src="template/images/bitly.svg" class="bitly-logo m-0" /> <?= $language->dashboard->input->bitly ?></label>
                                    </div>
                                <?php endif ?>

                                <?php if(($settings->store_pro_features_schedule && $account->pro) || !$settings->store_pro_features_schedule): ?>
                                    <div class="schedule row" style="display: none;">
                                        <div class="col">
                                            <div class="form-group">
                                                <input
                                                    type="text"
                                                    class="form-control"
                                                    data-min="<?= str_replace(' ', 'T', $date) ?>"
                                                    name="start_date"
                                                    value=""
                                                    placeholder="<?= $language->dashboard->input->start_date ?>"
                                                    autocomplete="off"
                                                >
                                            </div>
                                        </div>

                                        <div class="col">
                                            <div class="form-group">
                                                <input
                                                    type="text"
                                                    class="form-control"
                                                    data-min="<?= str_replace(' ', 'T', $date) ?>"
                                                    name="end_date"
                                                    value=""
                                                    placeholder="<?= $language->dashboard->input->end_date ?>"
                                                    autocomplete="off"
                                                >
                                            </div>
                                        </div>
                                    </div>
                                <?php endif ?>
							</div>

							<div class="modal-footer">
								<button type="button" class="btn btn-secondary" data-dismiss="modal"><?= $language->global->close ?></button>
								<div class="text-center">
									<button type="submit" name="submit" class="btn btn-primary"><?= $language->global->submit_button ?></button>
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>

			<script>
                let edit_link_pickr = null;

				$('#edit_link').on('show.bs.modal', event => {
					let button = $(event.relatedTarget);
					let link_id = button.data('id');
					let title = button.data('title');
					let url = button.data('url');
                    let bitly = !!button.data('bitly');
                    let color = button.data('color');
					let modal = $(event.currentTarget);
                    let is_color = document.querySelector('#edit_link .color_button');
                    let start_date = button.data('start-date');
                    let end_date = button.data('end-date');

					modal.find('.modal-body input[name="title"]').val(title);
					modal.find('.modal-body input[name="url"]').val(url);
					modal.find('.modal-body input[name="link_id"]').val(link_id);
					modal.find('.modal-body input[name="color"]').val(color);
                    modal.find('.modal-body input[name="bitly"]').attr('checked', bitly);

                    /* Check if link is scheduled */
                    if(!!start_date && !!end_date) {
                        modal.find('.modal-body .schedule').show();
                        modal.find('.modal-body input[name="start_date"]').val(start_date);
                        modal.find('.modal-body input[name="end_date"]').val(end_date);
                    }

                    /* Colored link handling */
                    if(is_color) {

                        if(edit_link_pickr) {

                            edit_link_pickr.setColor(color);

                        } else {
                            edit_link_pickr = Pickr.create({
                                el: '#edit_link .color_button div',

                                default: color,

                                components: {
                                    preview: true,
                                    opacity: false,
                                    hue: true,
                                    comparison: false,
                                    interaction: {
                                        hex: true,
                                        rgba: false,
                                        hsla: false,
                                        hsva: false,
                                        cmyk: false,
                                        input: true,
                                        clear: false,
                                        save: true
                                    }
                                },

                                onSave(hsva, instance) {
                                    $('#edit_link input[name="color"]').val(hsva.toHEX().toString());
                                },
                            });
                        }

                    }
				});


			</script>


            <div class="modal fade" id="statistics_link" tabindex="-1" role="dialog" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title"><?= $language->dashboard->statistics_modal->header ?></h5>

                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>

                        <div class="modal-body">
                            <div class="mb-3">
                                <input
                                    type="text"
                                    class="form-control"
                                    id="datepicker_input"
                                    data-range="true"
                                    data-max="<?= str_replace(' ', 'T', $date) ?>"
                                    name="date_range"
                                    value=""
                                    placeholder="<?= $language->dashboard->statistics_modal->date_range ?>"
                                    autocomplete="off"
                                >
                            </div>

                            <div class="chart-container">
                                <canvas id="chart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <script>
                /* Generate the chart in the modal */
                let chart = new Chart(document.getElementById('chart').getContext('2d'), {
                    type: 'bar',
                    data: {
                        labels: [],
                        datasets: [{
                            label: '<?= $language->dashboard->statistics_modal->total_hits ?>',
                            data: [],
                            backgroundColor: 'rgb(255, 99, 132)',
                            fill: false
                        }]
                    },
                    options: {
                        tooltips: {
                            mode: 'index',
                            intersect: false,
                            callbacks: {
                                label: (tooltipItem, data) => {
                                    let value = data.datasets[tooltipItem.datasetIndex].data[tooltipItem.index];

                                    return number_format(value, 0, '<?= $language->global->number->decimal_point ?>',  '<?= $language->global->number->thousands_separator ?>');
                                }
                            }
                        },
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            yAxes: [{
                                ticks: {
                                    min: 0,
                                    userCallback: (value, index, values) => {
                                        if(Math.floor(value) === value) {
                                            return number_format(value, 0, '<?= $language->global->number->decimal_point ?>', '<?= $language->global->number->thousands_separator ?>');
                                        }
                                    }
                                }
                            }]
                        }
                    }
                });

                let chart_workflow = (data) => {
                    /* Clear the chart */
                    chart.data.labels = [];
                    chart.data.datasets[0].data = [];
                    chart.update();

                    /* Clear the datepicker */
                    $('#datepicker_input').val('');

                    $.ajax({
                        url: 'processing/process/statistics_link.php',
                        data: data,
                        type: 'GET',
                        dataType: 'json',
                        success: data => {
                            if(data.status == 'success') {

                                /* Add data to the chart */
                                data.details.labels.forEach(label => {
                                    chart.data.labels.push(label);
                                });

                                data.details.hits.forEach(hit => {
                                    chart.data.datasets[0].data.push(hit);
                                });

                                chart.update();

                                /* Initiate the datepicker */
                                $('#datepicker_input').datepicker({
                                    classes: 'datepicker-modal',
                                    language: 'en',
                                    dateFormat: 'yyyy-mm-dd',
                                    autoClose: true,
                                    timepicker: false,
                                    toggleSelected: false,
                                    minDate: false,
                                    maxDate: new Date($('#datepicker_input').data('max')),
                                    onSelect: (date, date_array) => {

                                        /* Only execute after two dates are selected */
                                        if(date_array.length > 1) {
                                            let [ date_start, date_end ] = date.split(',');

                                            if(typeof date_end == 'undefined') {
                                                date_end = date_start
                                            }

                                            chart_workflow({ link_id, url_token, date_start, date_end });
                                        }

                                    }
                                });
                            }
                        }
                    });
                };

                let link_id = null;
                let url_token = null;

                $('#statistics_link').on('show.bs.modal', event => {
                    let button = $(event.relatedTarget);
                    link_id = button.data('id');
                    url_token = button.data('url-token');

                    chart_workflow({ link_id, url_token })
                });

            </script>

		<?php endif ?>

        <?php if($page == 'index'): ?>
        <script src="template/js/aos.min.js"></script>
        <script>
            $(document).ready(() => {
                AOS.init({
                    delay: 50,
                    duration: 600
                });
            });
        </script>
        <?php endif ?>

	</body>
</html>
