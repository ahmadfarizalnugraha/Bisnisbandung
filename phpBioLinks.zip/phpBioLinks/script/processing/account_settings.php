<?php
defined('ROOT') || die();
User::check_permission(0);

$method 	= (isset($parameters[0])) ? $parameters[0] : false;
$url_token 	= (isset($parameters[1])) ? $parameters[1] : false;

if(!empty($_POST)) {
    $allowed_extensions = ['jpg', 'jpeg', 'png'];
    $avatar = (!empty($_FILES['avatar']['name']));
    $background = (!empty($_FILES['background']['name']));

    /* Clean some posted variables */
    $_POST['email']		        = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $_POST['username']		    = generate_slug(filter_var($_POST['username'], FILTER_SANITIZE_STRING));
    $_POST['name']		        = filter_var($_POST['name'], FILTER_SANITIZE_STRING);
    $_POST['description']		= filter_var($_POST['description'], FILTER_SANITIZE_STRING);

    /* Check for any errors */
    if(!Security::csrf_check_session_token('form_token', $_POST['form_token'])) {
        $_SESSION['error'][] = $language->global->error_message->invalid_token;
    }
    if(strlen($_POST['username']) < 3 || strlen($_POST['username']) > 32) {
        $_SESSION['error'][] = $language->account_settings->error_message->username_length;
    }
    if(Database::exists('user_id', 'users', ['username' => $_POST['username']]) && $_POST['username'] !== $account->username) {
        $_SESSION['error'][] = sprintf($language->account_settings->error_message->user_exists, $_POST['username']);
    }
    if(filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) == false) {
        $_SESSION['error'][] = $language->account_settings->error_message->invalid_email;
    }
    if(Database::exists('user_id', 'users', ['email' => $_POST['email']]) && $_POST['email'] !== $account->email) {
        $_SESSION['error'][] = $language->account_settings->error_message->email_exists;
    }
    if(strlen($_POST['description']) > 128) {
        $_SESSION['error'][] = $language->account_settings->error_message->long_description;
    }
    if(strlen($_POST['name']) < 3 || strlen($_POST['name']) > 64) {
        $_SESSION['error'][] = $language->account_settings->error_message->name_length;
    }
    $regex = '/^[A-Za-z0-9]+[A-Za-z0-9_.]*[A-Za-z0-9]+$/';
    if(!preg_match($regex, $_POST['username'])) {
        $_SESSION['error'][] = $language->account_settings->error_message->username_characters;
    }
    if(in_array($_POST['username'], User::$banned_usernames)) {
        $_SESSION['error'][] = $language->account_settings->error_message->username_banned;
    }

    if(!empty($_POST['old_password']) && !empty($_POST['new_password'])) {
        if(!password_verify($_POST['old_password'], $account->password)) {
            $_SESSION['error'][] = $language->account_settings->error_message->invalid_current_password;
        }
        if(strlen(trim($_POST['new_password'])) < 6) {
            $_SESSION['error'][] = $language->account_settings->error_message->short_password;
        }
        if($_POST['new_password'] !== $_POST['repeat_password']) {
            $_SESSION['error'][] = $language->account_settings->error_message->passwords_not_matching;
        }
    }

    /* Check for any errors on the avatar image */
    if($avatar) {
        $avatar_file_name		= $_FILES['avatar']['name'];
        $avatar_file_extension	= pathinfo($avatar_file_name, PATHINFO_EXTENSION);
        $avatar_file_temp		= $_FILES['avatar']['tmp_name'];
        $avatar_file_size		= $_FILES['avatar']['size'];
        list($avatar_width, $avatar_height)	= getimagesize($avatar_file_temp);

        if(!is_writeable(AVATARS_ROUTE) || !is_writeable(AVATARS_THUMBS_ROUTE)) {
            $_SESSION['error'][] = $account->type > 0 ? $language->account_settings->error_message->not_writeable : $language->global->error_message->system_issues;
        }
        if(!in_array($avatar_file_extension, $allowed_extensions)) {
            $_SESSION['error'][] = $language->global->error_message->invalid_file_type;
        }
        if($avatar_width < 165 || $avatar_height < 165) {
            $_SESSION['error'][] = $language->account_settings->error_message->small_avatar;
        }
        if($avatar_file_size > $settings->avatar_max_size) {
            $_SESSION['error'][] = sprintf($language->global->error_message->invalid_image_size, formatBytes($settings->avatar_max_size));
        }
        if($_FILES['avatar']['error']) {
            $_SESSION['error'][] = $language->account_settings->error_message->upload_error;
        }
    }


    /* Check for any errors on the avatar image */
    if($background && (($settings->store_pro_features_background && $account->pro) || !$settings->store_pro_features_background)) {
        $background_file_name		= $_FILES['background']['name'];
        $background_file_extension	= pathinfo($background_file_name, PATHINFO_EXTENSION);
        $background_file_temp		= $_FILES['background']['tmp_name'];
        $background_file_size		= $_FILES['background']['size'];
        list($background_width, $background_height)	= getimagesize($background_file_temp);

        if(!is_writeable(BACKGROUNDS_ROUTE)) {
            $_SESSION['error'][] = $account->type > 0 ? $language->account_settings->error_message->not_writeable : $language->global->error_message->system_issues;
        }
        if(!in_array($background_file_extension, $allowed_extensions)) {
            $_SESSION['error'][] = $language->global->error_message->invalid_file_type;
        }
        if($background_width < 1000 || $background_height < 1000) {
            $_SESSION['error'][] = $language->account_settings->error_message->small_background;
        }
        if($background_file_size > $settings->avatar_max_size) {
            $_SESSION['error'][] = sprintf($language->global->error_message->invalid_image_size, formatBytes($settings->background_max_size));
        }
        if($_FILES['background']['error']) {
            $_SESSION['error'][] = $language->account_settings->error_message->upload_error;
        }
    }


    if(empty($_SESSION['error'])) {

        /* Prepare the statement and execute query */
        $stmt = $database->prepare("UPDATE `users` SET `email` = ?, `username` = ?, `name` = ?, `description` = ? WHERE `user_id` = {$account_user_id}");
        $stmt->bind_param('ssss', $_POST['email'], $_POST['username'], $_POST['name'], $_POST['description']);
        $stmt->execute();
        $stmt->close();

        /* Fb Pixel Update Process */
        if((($settings->store_pro_features_fb_pixel && $account->pro) || !$settings->store_pro_features_fb_pixel) && isset($_POST['fb_pixel'])) {
            $_POST['fb_pixel'] = Database::clean_string($_POST['fb_pixel']);

            $stmt = $database->prepare("UPDATE `users` SET `fb_pixel` = ? WHERE `user_id` = {$account_user_id}");
            $stmt->bind_param('s', $_POST['fb_pixel']);
            $stmt->execute();
            $stmt->close();

        }

        /* Bit.ly Token Update Process */
        if((($settings->store_pro_features_bitly && $account->pro) || !$settings->store_pro_features_bitly) && isset($_POST['bitly_token'])) {
            $_POST['bitly_token'] = Database::clean_string($_POST['bitly_token']);

            $stmt = $database->prepare("UPDATE `users` SET `bitly_token` = ? WHERE `user_id` = {$account_user_id}");
            $stmt->bind_param('s', $_POST['bitly_token']);
            $stmt->execute();
            $stmt->close();

        }

        /* Fb Pixel Update Process */
        if((($settings->store_pro_features_ga && $account->pro) || !$settings->store_pro_features_ga) && isset($_POST['ga'])) {
            $_POST['ga'] = Database::clean_string($_POST['ga']);

            $stmt = $database->prepare("UPDATE `users` SET `ga` = ? WHERE `user_id` = {$account_user_id}");
            $stmt->bind_param('s', $_POST['ga']);
            $stmt->execute();
            $stmt->close();

        }

        /* Avatar update process */
        if($avatar) {
            /* Delete current avatar & thumbnail if needed */
            if(!empty($account->avatar) && file_exists(AVATARS_ROUTE . $account->avatar)) {
                @unlink(AVATARS_ROUTE . $account->avatar);
            }
            if(!empty($account->avatar) && file_exists(AVATARS_THUMBS_ROUTE . $account->avatar)) {
                @unlink(AVATARS_THUMBS_ROUTE . $account->avatar);
            }

            /* Generate new name for avatar */
            $avatar_new_name = md5(time().rand()) . '.' . $avatar_file_extension;

            /* Make a thumbnail and upload the original */
            resize($avatar_file_temp, AVATARS_THUMBS_ROUTE . $avatar_new_name, '165', '165');
            move_uploaded_file($avatar_file_temp, AVATARS_ROUTE .$avatar_new_name);

            /* Execute query */
            $database->query("UPDATE `users` SET `avatar` = '{$avatar_new_name}' WHERE `user_id` = {$account_user_id}");
        }

        /* Background update process */
        if($background && (($settings->store_pro_features_background && $account->pro) || !$settings->store_pro_features_background)) {
            /* Delete current background if needed */
            if(!empty($account->avatar) && file_exists(ROOT . BACKGROUNDS_ROUTE . $account->background)) {
                @unlink(BACKGROUNDS_ROUTE . $account->background);
            }

            /* Generate new name for avatar */
            $background_new_name = md5(time().rand()) . '.' . $background_file_extension;

            /* Make a thumbnail and upload the original */
            move_uploaded_file($background_file_temp, ROOT . BACKGROUNDS_ROUTE . $background_new_name);

            /* Execute query */
            $database->query("UPDATE `users` SET `background` = '{$background_new_name}' WHERE `user_id` = {$account_user_id}");
        }

        /* Set the success message */
        $_SESSION['success'][] = $language->account_settings->success_message->account_updated;

        /* Refresh the account details variable */
        $account = Database::get('*', 'users', ['user_id' => $account_user_id]);

        if(!empty($_POST['old_password']) && !empty($_POST['new_password'])) {
            $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);

            Database::update('users', ['password' => $new_password], ['user_id' => $account_user_id]);

            /* Set a success message and log out the user */
            User::logout();
        }
    }

}

if($method && in_array($method, ['delete', 'background-remove'])) {

    if(!Security::csrf_check_session_token('url_token', $url_token)) {
        $_SESSION['error'][] = $language->global->error_message->invalid_token;
    }


    if(empty($_SESSION['error'])) {

        switch($method) {
            case 'delete':

                /* Delete the user */
                User::delete_user($account_user_id);
                User::logout();

                break;

            case 'background-remove':

                /* Delete the current background */
                if(!empty($account->background) && file_exists(ROOT . BACKGROUNDS_ROUTE . $account->background)) {
                    unlink(ROOT . BACKGROUNDS_ROUTE . $account->background);
                }

                /* Execute query */
                $database->query("UPDATE `users` SET `background` = '' WHERE `user_id` = {$account_user_id}");

                break;
        }

        /* Set message & redirect */
        $_SESSION['success'][] = $language->global->success_message->basic;
    }


    redirect('account-settings');

}
