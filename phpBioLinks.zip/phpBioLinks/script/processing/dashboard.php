<?php
defined('ROOT') || die();
User::check_permission(0);

$method 	= (isset($parameters[0])) ? $parameters[0] : false;
$link_id    = (int) (isset($parameters[1])) ? $parameters[1] : false;
$url_token 	= (isset($parameters[2])) ? $parameters[2] : false;


if(!empty($_POST)) {

    if(isset($_POST['link_id'])) {
        /* Clean some posted variables */
        $_POST['link_id']   = (int) $_POST['link_id'];
        $_POST['title']     = filter_var($_POST['title'], FILTER_SANITIZE_STRING);
        $_POST['url']       = Database::clean_string($_POST['url']);
        $_POST['color']     = (!isset($_POST['color'])) ? '#000' : $_POST['color'];
        $short_url          = '';
        $start_date         = '';
        $end_date           = '';

        if(($settings->store_pro_features_colored && $account->pro) || !$settings->store_pro_features_colored) {
            $valid_color = preg_match('/#([a-f0-9]{3}){1,2}\b/i', $_POST['color']);

            $_POST['color'] = $valid_color ? Database::clean_string($_POST['color']) : '#000';
        }

        /* Bitly Integration */
        if(!empty($account->bitly_token) && isset($_POST['bitly']) && (($settings->store_pro_features_bitly && $account->pro) || !$settings->store_pro_features_bitly)) {
            $bitly = new Bitly($account->bitly_token);

            try {
                $bitly_response = $bitly->shorten($_POST['url']);

                $short_url = $bitly_response->link;
            } catch (Exception $error) {
                $_SESSION['error'][] = $error->getMessage();
            }
        }

        /* Scheduling */
        if(
            isset($_POST['start_date'], $_POST['end_date'])
            && !empty($_POST['start_date'])
            && !empty($_POST['end_date'])
            && validate_date($_POST['start_date'], 'Y-m-d H:i:s')
            && validate_date($_POST['end_date'], 'Y-m-d H:i:s')
            && (($settings->store_pro_features_schedule && $account->pro) || !$settings->store_pro_features_schedule)
        ) {

            $start_date = $_POST['start_date'];
            $end_date   = $_POST['end_date'];

        }

        if(!Security::csrf_check_session_token('form_token', $_POST['form_token'])) {
            $_SESSION['error'][] = $language->global->error_message->invalid_token;
        }
        if(Database::simple_get('user_id', 'links', ['link_id' => $_POST['link_id']]) != $account_user_id) {
            $_SESSION['error'][] = '';
        }
        if (strlen($_POST['title']) < 3) {
            $_SESSION['error'][] = $language->dashboard->error_message->title_length;
        }
        if(!validate_url_format($_POST['url'])) {
            $_SESSION['error'][] = $language->dashboard->error_message->invalid_url;
        }

        if(empty($_SESSION['error'])) {
            /* Prepare the statement and execute query */
            $stmt = $database->prepare("UPDATE `links` SET `title` = ?, `url` = ?, `short_url` = ?, `color` = ?, `start_date` = ?, `end_date` = ? WHERE `link_id` = {$_POST['link_id']}");
            $stmt->bind_param('ssssss', $_POST['title'], $_POST['url'], $short_url, $_POST['color'], $start_date, $end_date);
            $stmt->execute();
            $stmt->close();

            /* Success */
            $_SESSION['success'][] = $language->dashboard->success_message->edited;
            redirect('dashboard');
        }
    }

    else {

        /* Clean some posted variables */
        $_POST['title']     = filter_var($_POST['title'], FILTER_SANITIZE_STRING);
        $_POST['url']       = Database::clean_string($_POST['url']);
        $_POST['color']     = (!isset($_POST['color'])) ? '' : $_POST['color'];
        $short_url          = '';
        $start_date         = '';
        $end_date           = '';

        if(($settings->store_pro_features_colored && $account->pro) || !$settings->store_pro_features_colored) {
            $valid_color = preg_match('/#([a-f0-9]{3}){1,2}\b/i', $_POST['color']);

            $_POST['color'] = $valid_color ? Database::clean_string($_POST['color']) : '#000';
        }

        if($settings->user_links_limit > 0 && !$account->pro) {
            /* Check if the user has exceeded the limit */
            $total_links = Database::exists('link_id', 'links', ['user_id' => $account_user_id]);

            if($total_links >= $settings->user_links_limit) {
                $_SESSION['error'][] = sprintf($language->dashboard->error_message->user_links_limit, $settings->user_links_limit);
            }
        }

        /* Bitly Integration */
        if(!empty($account->bitly_token) && isset($_POST['bitly']) && (($settings->store_pro_features_bitly && $account->pro) || !$settings->store_pro_features_bitly)) {
            $bitly = new Bitly($account->bitly_token);

            try {
                $bitly_response = $bitly->shorten($_POST['url']);

                $short_url = $bitly_response->link;
            } catch (Exception $error) {
                $_SESSION['error'][] = $error->getMessage();
            }
        }

        /* Scheduling */
        if(
            isset($_POST['start_date'], $_POST['end_date'])
            && !empty($_POST['start_date'])
            && !empty($_POST['end_date'])
            && validate_date($_POST['start_date'], 'Y-m-d H:i:s')
            && validate_date($_POST['end_date'], 'Y-m-d H:i:s')
            && (($settings->store_pro_features_schedule && $account->pro) || !$settings->store_pro_features_schedule)
        ) {

            $start_date = $_POST['start_date'];
            $end_date   = $_POST['end_date'];

        }

        if(!Security::csrf_check_session_token('form_token', $_POST['form_token'])) {
            $_SESSION['error'][] = $language->global->error_message->invalid_token;
        }
        if(!validate_url_format($_POST['url'])) {
            $_SESSION['error'][] = $language->dashboard->error_message->invalid_url;
        }
        if(strlen($_POST['title']) < 3) {
            $_SESSION['error'][] = $language->dashboard->error_message->title_length;
        }

        if(empty($_SESSION['error'])) {

            /* Add the user to the database */
            $stmt = $database->prepare("INSERT INTO `links` (`user_id`, `title`, `url`, `short_url`, `date`, `color`, `start_date`, `end_date`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param('ssssssss', $account_user_id, $_POST['title'], $_POST['url'], $short_url, $date, $_POST['color'], $start_date, $end_date);
            $stmt->execute();
            $stmt->close();

            /* Success */
            $_SESSION['success'][] = $language->dashboard->success_message->basic;
            redirect('dashboard');
        }

    }
}

if($method && $method == 'delete') {

    if(!Security::csrf_check_session_token('url_token', $url_token)) {
        $_SESSION['error'][] = $language->global->error_message->invalid_token;
    }

    if(empty($_SESSION['error'])) {

        /* Remove the link and the hits */
        $stmt = $database->prepare("DELETE FROM `links` WHERE `link_id` = ?");
        $stmt->bind_param('s', $link_id);
        $stmt->execute();
        $stmt->close();

        $stmt = $database->prepare("DELETE FROM `hits` WHERE `link_id` = ?");
        $stmt->bind_param('s', $link_id);
        $stmt->execute();
        $stmt->close();

        /* Success */
        $_SESSION['success'][] = $language->dashboard->success_message->deleted;
        redirect('dashboard');
    }
}


$links_result = $database->query("SELECT * FROM `links` WHERE `user_id` = {$account_user_id} ORDER BY `order` ASC, `link_id` DESC");
$total_links = Database::exists('link_id', 'links', ['user_id' => $account_user_id]);
$total_hits = $database->query("SELECT SUM(`hits`) AS `total` FROM `links` WHERE `user_id` = {$account_user_id}")->fetch_object()->total;

/* Get the days remaining of pro if current account is pro */
if($account->pro) {
    $pro_days_left = $database->query("SELECT DATEDIFF(`pro_due_date`, NOW()) AS `days_left` FROM `users` WHERE `user_id` = {$account_user_id} ")->fetch_object()->days_left;
}
