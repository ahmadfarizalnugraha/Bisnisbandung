<?php
defined('ROOT') || die();

if(!$profile_account = Database::get('*', 'users', ['username' => $profile_username])) {
    redirect();
}

$_SESSION['profile_user_id'] = $profile_user_id = $profile_account->user_id;

$links_result = $database->query("SELECT * FROM `links` WHERE `user_id` = {$profile_user_id} ORDER BY `order` ASC, `link_id` DESC");

/* Determine if the profile has an active background */
$background_style = (($settings->store_pro_features_background && $profile_account->pro) || !$settings->store_pro_features_background) && !empty($profile_account->background) ? 'background-image: url(\'' . User::display_image(BACKGROUNDS_ROUTE . $profile_account->background) . '\');' : null;
