<?php
include '../../core/init.php';
User::check_permission(0);

if(!empty($_POST) && isset($_POST['data']) && is_array($_POST['data']) && Security::csrf_check_session_token('form_token', $_POST['form_token'])) {
    foreach($_POST['data'] as $link) {
        $link['link_id'] = (int) $link['link_id'];
        $link['order'] = (int) $link['order'];

        if(Database::simple_get('user_id', 'links', ['link_id' => $link['link_id']]) == $account_user_id) {
            /* Prepare the statement and execute query */
            $stmt = $database->prepare("UPDATE `links` SET `order` = ? WHERE `link_id` = {$link['link_id']}");
            $stmt->bind_param('s', $link['order']);
            $stmt->execute();
            $stmt->close();
        }

    }

}