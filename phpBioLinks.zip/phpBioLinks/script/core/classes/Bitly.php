<?php
use Unirest\Request;

class Bitly {

    private $api_url = 'https://api-ssl.bitly.com/v4/';
    private $api_key = false;

    public function __construct($api_key) {

        if(!function_exists('curl_version')) {

            throw new Exception('Your webhost does not support curl and we cannot continue with the request.');

        }

        $this->api_key = $api_key;

    }

    public function shorten($long_url) {
        global $language;

        $headers = [
            'Accept' => 'application/json',
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $this->api_key
        ];

        $body = json_encode([
            'long_url' => $long_url
        ]);


        $response = Request::post($this->api_url . 'shorten', $headers, $body);

        if($response->code == 403) {
            throw new Exception($language->dashboard->error_message->bitly_forbidden);
        }

        if($response->code != 403 && $response->code != 200 && $response->code != 201) {
            throw new Exception($language->dashboard->error_message->bitly_failed);
        }

        return $response->body;
    }



    public function parse($raw_body) {

       return $raw_body;
    }


}
