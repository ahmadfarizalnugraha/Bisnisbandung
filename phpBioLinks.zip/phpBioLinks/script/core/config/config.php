<?php
$config = [];

$config['database_server'] = 'localhost';
$config['database_username'] = 'root';
$config['database_password'] = '';
$config['database_name'] = 'dump';
$config['url'] = 'http://localhost/phpBioLinks/script/';
