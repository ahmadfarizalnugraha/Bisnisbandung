<?php
defined('ROOT') || die();
User::check_permission(1);

$link_id = (isset($parameters[0])) ? (int) $parameters[0] : false;

/* Make sure the link exists */
if(!$link = Database::get('*', 'links', ['link_id' => $link_id])) {
	User::get_back('admin/links-management');
}

if(!empty($_POST)) {
	/* Clean some posted variables */
	$_POST['title'] = filter_var($_POST['title'], FILTER_SANITIZE_STRING);
	$_POST['url'] = Database::clean_string($_POST['url']);


	if (!validate_url_format($_POST['url'])) {
		$_SESSION['error'][] = $language->admin_link_edit->error_message->invalid_url;
	}
	if (strlen($_POST['title']) < 3) {
		$_SESSION['error'][] = $language->admin_link_edit->error_message->title_length;
	}
    if(!Security::csrf_check_session_token('form_token', $_POST['form_token'])) {
        $_SESSION['error'][] = $language->global->error_message->invalid_token;
    }

	if(empty($_SESSION['error'])) {
		/* Prepare the statement and execute query */
		$stmt = $database->prepare("UPDATE `links` SET `title` = ?, `url` = ? WHERE `link_id` = {$link_id}");
		$stmt->bind_param('ss', $_POST['title'], $_POST['url']);
		$stmt->execute();
		$stmt->close();

		/* Success */
		$_SESSION['success'][] = $language->global->success_message->basic;
	}

	display_notifications();
}

$link = Database::get('*', 'links', ['link_id' => $link_id]);
?>

<div class="card card-shadow">
    <div class="card-body">

        <h4 class="d-flex justify-content-between">
            <div class="d-flex">
                <span class="mr-3"><?= $language->admin_link_edit->header ?></span>

                <?= User::admin_generate_buttons('link', $link_id) ?>
            </div>

            <div><?= User::generate_go_back_button('admin/links-management') ?></div>
        </h4>

        <form action="" method="post" role="form">
            <input type="hidden" name="form_token" value="<?= Security::csrf_get_session_token('form_token') ?>" />

            <div class="form-group">
                <div class="d-flex">
                    <?php if(!empty($link->color)): ?>
                        <span class="round-shape" style="background-color: <?= $link->color ?>"></span>
                    <?php endif ?>
                    <?php if(!empty($link->short_url)): ?>
                        <img src="template/images/bitly.svg" class="bitly-logo" data-toggle="tooltip" title="<?= $language->dashboard->display->bitly_url ?>" />
                    <?php endif ?>
                    <?= $language->admin_link_edit->input->title ?>
                </div>
                <input type="text" class="form-control" name="title" value="<?= $link->title ?>">
            </div>

            <div class="form-group">
                <label><?= $language->admin_link_edit->input->url ?></label>
                <input type="text" class="form-control" name="url" value="<?= $link->url ?>" <?= !empty($link->short_url) ? 'disabled="disabled"' : null ?>>
            </div>

            <div class="form-group">
                <label><?= $language->admin_link_edit->input->hits ?></label>
                <input type="text" class="form-control" value="<?= $link->hits ?>" disabled="disabled">
            </div>

            <div class="form-group">
                <label><?= $language->admin_link_edit->input->date ?></label>
                <input type="text" class="form-control" value="<?= $link->date ?>" disabled="disabled">
            </div>

            <div class="form-group">
                <label><?= $language->admin_link_edit->input->color ?></label>
                <input type="text" class="form-control" value="<?= $link->color ?>" disabled="disabled">
            </div>

            <div class="form-group">
                <label><?= $language->admin_link_edit->input->user ?></label>
                <label><?= User::get_profile_link($link->user_id) ?></label>
            </div>

            <div class="text-center">
                <button type="submit" name="submit" class="btn btn-primary"><?= $language->global->submit_button ?></button>
            </div>
        </form>

    </div>
</div>


