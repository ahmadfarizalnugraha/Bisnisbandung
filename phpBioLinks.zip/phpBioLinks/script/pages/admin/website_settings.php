<?php
defined('ROOT') || die();
User::check_permission(1);

$method     = (isset($parameters[0]) && $parameters[0] == 'remove-logo') ? $parameters[0] : false;
$url_token 	= (isset($parameters[1])) ? $parameters[1] : false;

if($method && $url_token && Security::csrf_check_session_token('url_token', $url_token)) {

    /* Delete the current log */
    if(!empty($settings->logo) && file_exists(ROOT . UPLOADS_ROUTE . 'logo/' . $settings->logo)) {
        unlink(ROOT . UPLOADS_ROUTE . 'logo/' . $settings->logo);
    }

    /* Remove it from db */
    $database->query("UPDATE `settings` SET `logo` = '' WHERE `id` = 1");

    /* Set message & Redirect */
    $_SESSION['success'][] = $language->global->success_message->basic;
    redirect('admin/website-settings');
}

if(!empty($_POST)) {
    /* Define some variables */
    $allowed_extensions = ['jpg', 'jpeg', 'png'];
    $logo = (!empty($_FILES['logo']['name']));
    $logo_name = $logo ? '' : $settings->logo;
    $_POST['title']				 		= filter_var($_POST['title'], FILTER_SANITIZE_STRING);
	$_POST['meta_description']	 		= filter_var($_POST['meta_description'], FILTER_SANITIZE_STRING);
	$_POST['time_zone']					= filter_var($_POST['time_zone'], FILTER_SANITIZE_STRING);
    $_POST['email_confirmation']	 	= (int) ($_POST['email_confirmation']) ? 1 : 0;
	$_POST['avatar_max_size']	 		= (int) $_POST['avatar_max_size'];
    $_POST['background_max_size']	    = (int) $_POST['background_max_size'];
    $_POST['user_links_limit']          = (int) $_POST['user_links_limit'];

	$_POST['store_paypal_client_id']	= filter_var($_POST['store_paypal_client_id'], FILTER_SANITIZE_STRING);
	$_POST['store_paypal_secret'] 		= filter_var($_POST['store_paypal_secret'], FILTER_SANITIZE_STRING);
	$_POST['store_currency']		 	= filter_var($_POST['store_currency'], FILTER_SANITIZE_STRING);
    $_POST['store_pro_trial']           = (int) $_POST['store_pro_trial'];

    $_POST['store_pro_features']        = json_encode([
        'store_pro_features_colored'    => isset($_POST['store_pro_features_colored']),
        'store_pro_features_verified'   => isset($_POST['store_pro_features_verified']),
        'store_pro_features_fb_pixel'   => isset($_POST['store_pro_features_fb_pixel']),
        'store_pro_features_bitly'      => isset($_POST['store_pro_features_bitly']),
        'store_pro_features_background' => isset($_POST['store_pro_features_background']),
        'store_pro_features_ga'         => isset($_POST['store_pro_features_ga']),
        'store_pro_features_schedule'   => isset($_POST['store_pro_features_schedule']),
    ]);

	$_POST['public_key']				= filter_var($_POST['public_key'], FILTER_SANITIZE_STRING);
	$_POST['private_key']				= filter_var($_POST['private_key'], FILTER_SANITIZE_STRING);
	$_POST['facebook_app_id']			= filter_var($_POST['facebook_app_id'], FILTER_SANITIZE_STRING);
	$_POST['facebook_app_secret']		= filter_var($_POST['facebook_app_secret'], FILTER_SANITIZE_STRING);
    $_POST['instagram_client_id']		= filter_var($_POST['instagram_client_id'], FILTER_SANITIZE_STRING);
    $_POST['instagram_client_secret']	= filter_var($_POST['instagram_client_secret'], FILTER_SANITIZE_STRING);
	$_POST['analytics_code']	 		= filter_var($_POST['analytics_code'], FILTER_SANITIZE_STRING);

	$_POST['facebook']					= filter_var($_POST['facebook'], FILTER_SANITIZE_STRING);
	$_POST['twitter']					= filter_var($_POST['twitter'], FILTER_SANITIZE_STRING);
	$_POST['instagram']				    = filter_var($_POST['instagram'], FILTER_SANITIZE_STRING);
    $_POST['youtube']				    = filter_var($_POST['youtube'], FILTER_SANITIZE_STRING);

    $_POST['smtp_from']				    = filter_var($_POST['smtp_from'], FILTER_SANITIZE_STRING);
    $_POST['smtp_host']					= filter_var($_POST['smtp_host'], FILTER_SANITIZE_STRING);
    $_POST['smtp_port']					= (int) $_POST['smtp_port'];
    $_POST['smtp_encryption']			= filter_var($_POST['smtp_encryption'], FILTER_SANITIZE_STRING);
    $_POST['smtp_user']					= filter_var((isset($_POST['smtp_user'])) ? $_POST['smtp_user'] : '', FILTER_SANITIZE_STRING) ;
    $_POST['smtp_pass']                 = isset($_POST['smtp_pass']) ? $_POST['smtp_pass'] : '';
    $_POST['smtp_auth']	 	            = (isset($_POST['smtp_auth'])) ? '1' : '0';

    /* Check for any errors on the avatar image */
    if ($logo) {
        $logo_file_name = $_FILES['logo']['name'];
        $logo_file_extension = explode('.', $logo_file_name);
        $logo_file_extension = strtolower(end($logo_file_extension));
        $logo_file_temp = $_FILES['logo']['tmp_name'];
        $logo_file_size = $_FILES['logo']['size'];
        list($logo_width, $logo_height) = getimagesize($logo_file_temp);

        if (!in_array($logo_file_extension, $allowed_extensions)) {
            $_SESSION['error'][] = $language->global->error_message->invalid_file_type;
        }

        if (!is_writable(ROOT . UPLOADS_ROUTE . 'logo/')) {
            $_SESSION['error'][] = sprintf($language->global->error_message->directory_not_writeable, ROOT . UPLOADS_ROUTE . 'logo/');
        }

        if (empty($_SESSION['error'])) {

            /* Delete current avatar & thumbnail */
            if(!empty($settings->logo) && file_exists(ROOT . UPLOADS_ROUTE . 'logo/' . $settings->logo)) {
                unlink(ROOT . UPLOADS_ROUTE . 'logo/' . $settings->logo);
            }

            /* Generate new name for avatar */
            $logo_new_name = md5(time() . rand()) . '.' . $logo_file_extension;

            /* Make a thumbnail and upload the original */
            move_uploaded_file($logo_file_temp, ROOT . UPLOADS_ROUTE . 'logo/' . $logo_new_name);

            /* Execute query */
            $database->query("UPDATE `settings` SET `logo` = '{$logo_new_name}' WHERE `id` = 1");

        }
    }

    if(!Security::csrf_check_session_token('form_token', $_POST['form_token'])) {
        $_SESSION['error'][] = $language->global->error_message->invalid_token;
    }

    if(is_null(json_decode($_POST['links_allowed_prefixes']))) {
        $_SESSION['error'][] = $language->admin_website_settings->error_message->invalid_links_allowed_prefixes;
    }

    if(empty($_SESSION['error'])) {

        /* Prepare the statement and execute query */
        $stmt = $database->prepare("
		UPDATE
			`settings`
		SET
			`title` = ?,
			`default_language` = ?,
			`user_links_limit` = ?,
			`meta_description` = ?,
			`time_zone` = ?,
			`email_confirmation` = ?,
			`avatar_max_size` = ?,
            `background_max_size` = ?,
			`links_allowed_prefixes` = ?,
            
            `store_paypal_mode` = ?,
			`store_paypal_client_id` = ?,
			`store_paypal_secret` = ?,
			`store_stripe_publishable_key` = ?,
			`store_stripe_secret_key` = ?,

			`store_currency` = ?,
			`store_pro_price_month` = TRUNCATE(?, 2),
            `store_pro_price_year` = TRUNCATE(?, 2),
            `store_pro_features` = ?,
            `store_pro_trial` = ?,
            `email_pro_due_date` = ?,

			`top_ads` = ?,
			`bottom_ads` = ?,
			`profile_ads` = ?,

			`recaptcha` = ?,
			`public_key` = ?,
			`private_key` = ?,
			`facebook_login` = ?,
			`facebook_app_id` = ?,
			`facebook_app_secret` = ?,
			`instagram_login` = ?,
			`instagram_client_id` = ?,
			`instagram_client_secret` = ?,
			`analytics_code` = ?,

			`facebook` = ?,
			`twitter` = ?,
			`instagram` = ?,
			`youtube` = ?,
			
            `smtp_host` = ?,
			`smtp_port` = ?,
			`smtp_encryption` = ?,
			`smtp_auth` = ?,
			`smtp_user` = ?,
			`smtp_pass` = ?,
            `smtp_from` = ?

		WHERE `id` = 1
	");
        $stmt->bind_param('ssssssssssssssssssssssssssssssssssssssssssss',
            $_POST['title'],
            $_POST['default_language'],
            $_POST['user_links_limit'],
            $_POST['meta_description'],
            $_POST['time_zone'],
            $_POST['email_confirmation'],
            $_POST['avatar_max_size'],
            $_POST['background_max_size'],
            $_POST['links_allowed_prefixes'],
            $_POST['store_paypal_mode'],
            $_POST['store_paypal_client_id'],
            $_POST['store_paypal_secret'],
            $_POST['store_stripe_publishable_key'],
            $_POST['store_stripe_secret_key'],
            $_POST['store_currency'],
            $_POST['store_pro_price_month'],
            $_POST['store_pro_price_year'],
            $_POST['store_pro_features'],
            $_POST['store_pro_trial'],
            $_POST['email_pro_due_date'],
            $_POST['top_ads'],
            $_POST['bottom_ads'],
            $_POST['profile_ads'],
            $_POST['recaptcha'],
            $_POST['public_key'],
            $_POST['private_key'],
            $_POST['facebook_login'],
            $_POST['facebook_app_id'],
            $_POST['facebook_app_secret'],
            $_POST['instagram_login'],
            $_POST['instagram_client_id'],
            $_POST['instagram_client_secret'],
            $_POST['analytics_code'],
            $_POST['facebook'],
            $_POST['twitter'],
            $_POST['instagram'],
            $_POST['youtube'],
            $_POST['smtp_host'],
            $_POST['smtp_port'],
            $_POST['smtp_encryption'],
            $_POST['smtp_auth'],
            $_POST['smtp_user'],
            $_POST['smtp_pass'],
            $_POST['smtp_from']
        );
        $stmt->execute();
        $stmt->close();

        /* Refresh data */
        $settings = get_settings();

        /* Set message */
        $_SESSION['success'][] = $language->global->success_message->basic;

        display_notifications();
    }
}

?>

<div class="card card-shadow mb-3">
    <div class="card-body">
        <ul class="nav nav-pills" role="tablist">
            <li class="nav-item"><a class="nav-link active" href="#main" data-toggle="pill" role="tab"><?= $language->admin_website_settings->tab->main ?></a></li>
            <li class="nav-item"><a class="nav-link" href="#store" data-toggle="pill" role="tab"><?= $language->admin_website_settings->tab->store ?></a></li>
            <li class="nav-item"><a class="nav-link" href="#ads" data-toggle="pill" role="tab"><?= $language->admin_website_settings->tab->ads ?></a></li>
            <li class="nav-item"><a class="nav-link" href="#api" data-toggle="pill" role="tab"><?= $language->admin_website_settings->tab->api ?></a></li>
            <li class="nav-item"><a class="nav-link" href="#social" data-toggle="pill" role="tab"><?= $language->admin_website_settings->tab->social ?></a></li>
            <li class="nav-item"><a class="nav-link" href="#email" data-toggle="pill" role="tab"><?= $language->admin_website_settings->tab->email ?></a></li>
        </ul>
    </div>
</div>

<div class="card card-shadow">
    <div class="card-body">

        <form action="" method="post" role="form" enctype="multipart/form-data">
            <input type="hidden" name="form_token" value="<?= Security::csrf_get_session_token('form_token') ?>" />

            <div class="tab-content">
                <div class="tab-pane fade show active" id="main">
                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->title ?></label>
                        <input type="text" name="title" class="form-control" value="<?= $settings->title ?>" />
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->default_language ?></label>
                        <select name="default_language" class="form-control">
                            <?php foreach($languages as $value) echo '<option value="' . $value . '" ' . (($settings->default_language == $value) ? 'selected' : null) . '>' . $value . '</option>' ?>
                        </select>
                        <small class="text-muted"><?= $language->admin_website_settings->input->default_language_help ?></small>
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->logo ?></label>
                        <?php if($settings->logo != ''): ?>
                            <div class="m-1">
                                <img src="<?= $settings->url . UPLOADS_ROUTE . 'logo/' . $settings->logo ?>" class="img-fluid" />
                            </div>
                        <?php endif ?>
                        <input id="logo-file-input" type="file" name="logo" class="form-control" />
                        <small class="text-muted"><?= $language->admin_website_settings->input->logo_help ?></small>
                        <small class="text-muted"><a href="admin/website-settings/remove-logo/<?= Security::csrf_get_session_token('url_token') ?>"><?= $language->admin_website_settings->input->logo_remove ?></a></small>
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->meta_description ?></label>
                        <input type="text" name="meta_description" class="form-control" value="<?= $settings->meta_description ?>" />
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->time_zone ?></label>
                        <select name="time_zone" class="form-control">
                            <?php foreach(DateTimeZone::listIdentifiers() as $time_zone) echo '<option value="' . $time_zone . '" ' . (($settings->time_zone == $time_zone) ? 'selected' : null) . '>' . $time_zone . '</option>' ?>
                        </select>
                    </div>


                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->links_allowed_prefixes ?></label>
                        <textarea class="form-control" name="links_allowed_prefixes" style="height: 10rem;"><?= json_encode($settings->links_allowed_prefixes) ?></textarea>
                        <small class="text-muted"><?= $language->admin_website_settings->input->links_allowed_prefixes_help ?></small>
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->avatar_max_size ?></label>
                        <input type="text" name="avatar_max_size" class="form-control" value="<?= $settings->avatar_max_size ?>" />
                        <small class="text-muted"><?= $language->admin_website_settings->input->avatar_max_size_help ?></small>
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->background_max_size ?></label>
                        <input type="text" name="background_max_size" class="form-control" value="<?= $settings->background_max_size ?>" />
                        <small class="text-muted"><?= $language->admin_website_settings->input->background_max_size_help ?></small>
                    </div>
                </div>


                <div class="tab-pane fade" id="store">
                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->store_paypal_mode ?></label>

                        <select name="store_paypal_mode" class="form-control form-control">
                            <option value="live" <?= ($settings->store_paypal_mode == 'live') ? 'selected' : null ?>>live</option>
                            <option value="sandbox" <?= ($settings->store_paypal_mode == 'sandbox') ? 'selected' : null ?>>sandbox</option>
                        </select>

                        <small class="text-muted"><?= $language->admin_website_settings->input->store_paypal_mode_help ?></small>
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->store_paypal_client_id ?></label>
                        <input type="text" name="store_paypal_client_id" class="form-control" value="<?= $settings->store_paypal_client_id ?>" />
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->store_paypal_secret ?></label>
                        <input type="text" name="store_paypal_secret" class="form-control" value="<?= $settings->store_paypal_secret ?>" />
                    </div>

                    <hr />

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->store_stripe_publishable_key ?></label>
                        <input type="text" name="store_stripe_publishable_key" class="form-control" value="<?= $settings->store_stripe_publishable_key ?>" />
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->store_stripe_secret_key ?></label>
                        <input type="text" name="store_stripe_secret_key" class="form-control" value="<?= $settings->store_stripe_secret_key ?>" />
                    </div>

                    <hr />

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->store_currency ?></label>
                        <input type="text" name="store_currency" class="form-control" value="<?= $settings->store_currency ?>" />
                        <small class="form-text text-muted"><?= $language->admin_website_settings->input->store_currency_help ?></small>
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->store_pro_price_month ?></label>
                        <input type="text" name="store_pro_price_month" class="form-control" value="<?= $settings->store_pro_price_month ?>" />
                        <small class="text-muted"><?= $language->admin_website_settings->input->store_pro_price_month_help ?></small>
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->store_pro_price_year ?></label>
                        <input type="text" name="store_pro_price_year" class="form-control" value="<?= $settings->store_pro_price_year ?>" />
                        <small class="text-muted"><?= $language->admin_website_settings->input->store_pro_price_year_help ?></small>
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->store_pro_trial ?></label>
                        <input type="text" name="store_pro_trial" class="form-control" value="<?= $settings->store_pro_trial ?>" />
                        <small class="text-muted"><?= $language->admin_website_settings->input->store_pro_trial_help ?></small>
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->user_links_limit ?></label>
                        <input type="text" name="user_links_limit" class="form-control" value="<?= $settings->user_links_limit ?>" />
                        <small class="text-muted"><?= $language->admin_website_settings->input->user_links_limit_help ?></small>
                    </div>


                    <h5><?= $language->admin_website_settings->input->store_pro_features ?></h5>
                    <small class="text-muted"><?= $language->admin_website_settings->input->store_pro_features_help ?></small>

                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="store_pro_features_colored" name="store_pro_features_colored" <?php if($settings->store_pro_features_colored) echo 'checked' ?>>
                        <label class="custom-control-label" for="store_pro_features_colored"><?= $language->admin_website_settings->input->store_pro_features_colored ?></label>
                    </div>

                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="store_pro_features_verified" name="store_pro_features_verified" <?php if($settings->store_pro_features_verified) echo 'checked' ?>>
                        <label class="custom-control-label" for="store_pro_features_verified"><?= $language->admin_website_settings->input->store_pro_features_verified ?></label>
                    </div>

                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="store_pro_features_fb_pixel" name="store_pro_features_fb_pixel" <?php if($settings->store_pro_features_fb_pixel) echo 'checked' ?>>
                        <label class="custom-control-label" for="store_pro_features_fb_pixel"><?= $language->admin_website_settings->input->store_pro_features_fb_pixel ?></label>
                    </div>

                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="store_pro_features_bitly" name="store_pro_features_bitly" <?php if($settings->store_pro_features_bitly) echo 'checked' ?>>
                        <label class="custom-control-label" for="store_pro_features_bitly"><?= $language->admin_website_settings->input->store_pro_features_bitly ?></label>
                    </div>

                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="store_pro_features_background" name="store_pro_features_background" <?php if($settings->store_pro_features_background) echo 'checked' ?>>
                        <label class="custom-control-label" for="store_pro_features_background"><?= $language->admin_website_settings->input->store_pro_features_background ?></label>
                    </div>

                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="store_pro_features_ga" name="store_pro_features_ga" <?php if($settings->store_pro_features_ga) echo 'checked' ?>>
                        <label class="custom-control-label" for="store_pro_features_ga"><?= $language->admin_website_settings->input->store_pro_features_ga ?></label>
                    </div>

                    <div class="custom-control custom-switch">
                        <input type="checkbox" class="custom-control-input" id="store_pro_features_schedule" name="store_pro_features_schedule" <?php if($settings->store_pro_features_schedule) echo 'checked' ?>>
                        <label class="custom-control-label" for="store_pro_features_schedule"><?= $language->admin_website_settings->input->store_pro_features_schedule ?></label>
                    </div>
                </div>

                <div class="tab-pane fade" id="ads">
                    <p class="text-muted"><?= $language->admin_website_settings->input->ads_help ?></p>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->top_ads ?></label>
                        <textarea class="form-control" name="top_ads"><?= $settings->top_ads ?></textarea>
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->bottom_ads ?></label>
                        <textarea class="form-control" name="bottom_ads"><?= $settings->bottom_ads ?></textarea>
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->profile_ads ?></label>
                        <textarea class="form-control" name="profile_ads"><?= $settings->profile_ads ?></textarea>
                    </div>
                </div>

                <div class="tab-pane fade" id="api">
                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->recaptcha ?></label>

                        <select class="custom-select" name="recaptcha">
                            <option value="1" <?php if($settings->recaptcha) echo 'selected' ?>><?= $language->global->yes ?></option>
                            <option value="0" <?php if(!$settings->recaptcha) echo 'selected' ?>><?= $language->global->no ?></option>
                        </select>
                        <small class="text-muted"><?= $language->admin_website_settings->input->recaptcha_help ?></small>
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->public_key ?></label>
                        <input type="text" name="public_key" class="form-control" value="<?= $settings->public_key ?>" />
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->private_key ?></label>
                        <input type="text" name="private_key" class="form-control" value="<?= $settings->private_key ?>" />
                    </div>

                    <hr />

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->facebook_login ?></label>

                        <select class="custom-select" name="facebook_login">
                            <option value="1" <?php if($settings->facebook_login) echo 'selected' ?>><?= $language->global->yes ?></option>
                            <option value="0" <?php if(!$settings->facebook_login) echo 'selected' ?>><?= $language->global->no ?></option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->facebook_app_id ?></label>
                        <input type="text" name="facebook_app_id" class="form-control" value="<?= $settings->facebook_app_id ?>" />
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->facebook_app_secret ?></label>
                        <input type="text" name="facebook_app_secret" class="form-control" value="<?= $settings->facebook_app_secret ?>" />
                    </div>

                    <hr />

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->instagram_login ?></label>

                        <select class="custom-select" name="instagram_login">
                            <option value="1" <?php if($settings->instagram_login) echo 'selected' ?>><?= $language->global->yes ?></option>
                            <option value="0" <?php if(!$settings->instagram_login) echo 'selected' ?>><?= $language->global->no ?></option>
                        </select>
                    </div>


                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->instagram_client_id ?></label>
                        <input type="text" name="instagram_client_id" class="form-control" value="<?= $settings->instagram_client_id ?>" />
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->instagram_client_secret ?></label>
                        <input type="text" name="instagram_client_secret" class="form-control" value="<?= $settings->instagram_client_secret ?>" />
                    </div>

                    <hr />

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->analytics_code ?></label>
                        <input type="text" name="analytics_code" class="form-control" value="<?= $settings->analytics_code ?>" />
                        <small class="text-muted"><?= $language->admin_website_settings->input->analytics_code_help ?></small>
                    </div>

                </div>

                <div class="tab-pane fade" id="social">
                    <p class="text-muted"><?= $language->admin_website_settings->input->social_help ?></p>

                    <div class="form-group">
                        <label><i class="fab fa-facebook"></i> <?= $language->admin_website_settings->input->facebook ?></label>
                        <input type="text" name="facebook" class="form-control" value="<?= $settings->facebook ?>" />
                    </div>

                    <div class="form-group">
                        <label><i class="fab fa-twitter"></i> <?= $language->admin_website_settings->input->twitter ?></label>
                        <input type="text" name="twitter" class="form-control" value="<?= $settings->twitter ?>" />
                    </div>

                    <div class="form-group">
                        <label><i class="fab fa-instagram"></i> <?= $language->admin_website_settings->input->instagram ?></label>
                        <input type="text" name="instagram" class="form-control" value="<?= $settings->instagram ?>" />
                    </div>

                    <div class="form-group">
                        <label><i class="fab fa-youtube"></i> <?= $language->admin_website_settings->input->youtube ?></label>
                        <input type="text" name="youtube" class="form-control" value="<?= $settings->youtube ?>" />
                    </div>

                </div>

                <div class="tab-pane fade" id="email">

                    <h5>SMTP</h5>
                    <small class="form-text text-muted"><?= $language->admin_website_settings->input->smtp_help ?></small>


                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->smtp_host ?></label>
                        <input type="text" name="smtp_host" class="form-control" value="<?= $settings->smtp_host ?>" />
                        <small class="form-text text-muted"><?= $language->admin_website_settings->input->smtp_help ?></small>
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->smtp_from ?></label>
                        <input type="text" name="smtp_from" class="form-control" value="<?= $settings->smtp_from ?>" />
                        <small class="form-text text-muted"><?= $language->admin_website_settings->input->smtp_from_help ?></small>
                    </div>

                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label><?= $language->admin_website_settings->input->smtp_encryption ?></label>
                                <select name="smtp_encryption" class="form-control">
                                    <option value="0" <?= ($settings->smtp_encryption == '0') ? 'selected' : null ?>>None</option>
                                    <option value="ssl" <?= ($settings->smtp_encryption == 'ssl') ? 'selected' : null ?>>SSL</option>
                                    <option value="tls" <?= ($settings->smtp_encryption == 'tls') ? 'selected' : null ?>>TLS</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-md-9">
                            <div class="form-group">
                                <label><?= $language->admin_website_settings->input->smtp_port ?></label>
                                <input type="text" name="smtp_port" class="form-control" value="<?= $settings->smtp_port ?>" />
                            </div>
                        </div>
                    </div>

                    <div class="form-check">
                        <label class="form-check-label">
                            <input class="form-check-input" name="smtp_auth" type="checkbox" value="" <?= ($settings->smtp_auth) ? 'checked' : null ?>>
                            <?= $language->admin_website_settings->input->smtp_auth ?>
                        </label>
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->smtp_user ?></label>
                        <input type="text" name="smtp_user" class="form-control" value="<?= $settings->smtp_user ?>" <?= ($settings->smtp_auth) ? null : 'disabled' ?>/>
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->smtp_pass ?></label>
                        <input type="text" name="smtp_pass" class="form-control" value="<?= $settings->smtp_pass ?>" <?= ($settings->smtp_auth) ? null : 'disabled' ?>/>
                    </div>

                    <hr />

                    <h5>Other</h5>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->email_confirmation ?></label>

                        <select class="form-control" name="email_confirmation">
                            <option value="1" <?php if($settings->email_confirmation) echo 'selected' ?>><?= $language->global->yes ?></option>
                            <option value="0" <?php if(!$settings->email_confirmation) echo 'selected' ?>><?= $language->global->no ?></option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label><?= $language->admin_website_settings->input->email_pro_due_date ?> </label>
                        <input type="text" name="email_pro_due_date" class="form-control" value="<?= $settings->email_pro_due_date ?>" />
                        <small class="form-text text-muted"><?= $language->admin_website_settings->input->email_pro_due_date_help ?></small>
                    </div>
                </div>


                <div class="text-center">
                    <button type="submit" name="submit" class="btn btn-primary"><?= $language->global->submit_button ?></button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    $(document).ready(() => {

        $('input[name="cron_queries"]').on('keyup keypress blur change', (event) => {
            $('#queries_per_day').html(parseInt($(event.currentTarget).val()) * 1440);
        })

        $('input[name="smtp_auth"]').on('change', (event) => {

            if($(event.currentTarget).is(':checked')) {
                $('input[name="smtp_user"],input[name="smtp_pass"]').removeAttr('disabled');
            } else {
                $('input[name="smtp_user"],input[name="smtp_pass"]').attr('disabled', 'true');
            }

        })
    })
</script>
