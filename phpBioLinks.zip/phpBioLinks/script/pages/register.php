<?php
defined('ROOT') || die();
User::logged_in_redirect();

/* Default variables */
$register_username = $register_name = $register_email = '';

/* Initiate captcha */
$captcha = new Captcha($settings->recaptcha, $settings->public_key, $settings->private_key);

if(!empty($_POST)) {
	/* Clean some posted variables */
	$_POST['username']	= generate_slug(filter_var($_POST['username'], FILTER_SANITIZE_STRING));
	$_POST['name']		= filter_var($_POST['name'], FILTER_SANITIZE_STRING);
	$_POST['email']		= filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);

    /* Default variables */
    $register_username = $_POST['username'];
    $register_name = $_POST['name'];
    $register_email = $_POST['email'];

	/* Define some variables */
	$fields = ['username', 'name', 'email' ,'password'];

	/* Check for any errors */
	foreach($_POST as $key=>$value) {
		if(empty($value) && in_array($key, $fields) == true) {
			$_SESSION['error'][] = $language->global->error_message->empty_fields;
			break 1;
		}
	}
	if(!$captcha->is_valid()) {
		$_SESSION['error'][] = $language->global->error_message->invalid_captcha;
	}
	if(strlen($_POST['username']) < 3 || strlen($_POST['username']) > 32) {
		$_SESSION['error'][] = $language->register->error_message->username_length;
	}
	if(strlen($_POST['name']) < 3 || strlen($_POST['name']) > 64) {
		$_SESSION['error'][] = $language->register->error_message->name_length;
	}
	if(Database::exists('user_id', 'users', ['username' => $_POST['username']])) {
		$_SESSION['error'][] = sprintf($language->register->error_message->user_exists, $_POST['username']);
	}
	if(Database::exists('user_id', 'users', ['email' => $_POST['email']])) {
		$_SESSION['error'][] = $language->register->error_message->email_exists;
	}
	if(filter_var($_POST['email'], FILTER_VALIDATE_EMAIL) == false) {
		$_SESSION['error'][] = $language->register->error_message->invalid_email;
	}
	if(strlen(trim($_POST['password'])) < 6) {
		$_SESSION['error'][] = $language->register->error_message->short_password;
	}
	$regex = '/^[A-Za-z0-9]+[A-Za-z0-9_.]*[A-Za-z0-9]+$/';
	if(!preg_match($regex, $_POST['username'])) {
		$_SESSION['error'][] = $language->register->error_message->username_characters;
	}
    if(in_array($_POST['username'], User::$banned_usernames)) {
        $_SESSION['error'][] = $language->register->error_message->username_banned;
    }


	/* If there are no errors continue the registering process */
	if(empty($_SESSION['error'])) {
        /* Define some needed variables */
        $password   = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $active 	= ($settings->email_confirmation == 0) ? '1' : '0';
        $email_code = md5($_POST['email'] . microtime());
        $api_key = md5($_POST['email'].$_POST['username']);


		/* Add the user to the database */
		$stmt = $database->prepare("INSERT INTO `users` (`username`, `password`, `email`, `email_activation_code`, `name`, `active`, `date`) VALUES (?, ?, ?, ?, ?, ?, ?)");
		$stmt->bind_param('sssssss', $_POST['username'], $password, $_POST['email'], $email_code, $_POST['name'], $active, $date);

		$stmt->execute();
		$stmt->close();

		/* If active = 1 then login the user, else send the user an activation email */
		if($active == '1') {
			$_SESSION['user_id'] = $database->insert_id;
			$_SESSION['success'] = $language->register->success_message->login;
			redirect('dashboard');
		} else {
			$_SESSION['success'][] = $language->register->success_message->registration;
            sendmail($_POST['email'], sprintf($language->register->email->title, $settings->title), sprintf($language->register->email->content, $settings->url, $_POST['email'], $email_code));
			//printf($language->register->email->content, $settings->url, $_POST['email'], $email_code);
		}
	}

	display_notifications();

}

?>


<div class="d-flex justify-content-center">
	<div class="card card-shadow animated fadeIn col-md-5">
		<div class="card-body">

			<h4 class="card-title"><?= $language->register->header ?></h4>

			<form action="" method="post" role="form" class="mt-5">
				<div class="form-group">
					<label><?= $language->register->input->username ?></label>
					<input type="text" name="username" class="form-control" value="<?= $register_username ?>" />
				</div>

				<div class="form-group">
					<label><?= $language->register->input->name ?></label>
					<input type="text" name="name" class="form-control" value="<?= $register_name ?>" />
				</div>

				<div class="form-group">
					<label><?= $language->register->input->email ?></label>
					<input type="text" name="email" class="form-control" value="<?= $register_email ?>" />
				</div>

				<div class="form-group">
					<label><?= $language->register->input->password ?></label>
					<input type="password" name="password" class="form-control" />
				</div>

				<div class="form-group">
					  <?php $captcha->display() ?>
				</div>

				<div class="form-group mt-5">
					<button type="submit" name="submit" class="btn btn-default btn-block border-0 my-1"><?= $language->global->submit_button ?></button>
				</div>
			</form>
		</div>
	</div>
</div>
