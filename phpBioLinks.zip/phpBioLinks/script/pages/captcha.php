<?php
defined('ROOT') || die();
