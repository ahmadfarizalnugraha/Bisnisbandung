<?php defined('ROOT') || die() ?>

<div class="row d-flex justify-content-center">
    <div class="col-md-8">
        <div class="text-center">
            <img src="<?= User::display_image(AVATARS_THUMBS_ROUTE . $profile_account->avatar) ?>" class="mt-5 rounded-circle" style="max-width: 130px;max-height: 130px;" alt="<?= $profile_account->name ?>">

            <div class="m-5">
                <h3>
                    <span class="profile-header"><?= $profile_account->name ?></span>

                    <?php if(($settings->store_pro_features_verified && $profile_account->pro) || !$settings->store_pro_features_verified): ?>
                        <span data-toggle="tooltip" title="<?= $language->global->verified ?>" class="profile-verified-badge"><i class="fa fa-check-circle fa-xs"></i></span>
                    <?php endif ?>
                </h3>

                <?php if(!empty($profile_account->description)): ?>
                <span class="blockquote-footer profile-description"><?= $profile_account->description ?></span>
                <?php endif ?>
            </div>


            <?php if(!empty($settings->profile_ads) && !$profile_account->pro) echo $settings->profile_ads ?>


            <?php while($link = $links_result->fetch_object()): ?>

                <?php
                /* Check for link scheduling */
                $start_date = new DateTime($link->start_date);
                $end_date = new DateTime($link->end_date);
                $current_date = new DateTime();

                /* Skip showing the link if outside */
                if((($settings->store_pro_features_schedule && $profile_account->pro) || !$settings->store_pro_features_schedule) && !empty($link->start_date) && !empty($link->end_date) && ($current_date < $start_date || $current_date > $end_date)) {
                    continue;
                }

                ?>

                <?php
                /* Check if url is twitch */
                if(preg_match('/^(?:https?:\/\/)?(?:www\.)?(?:twitch\.tv\/)(.+)$/', $link->url, $twitch_match)):
                ?>
                    <div class="m-3">
                        <iframe width="100%" height="350" scrolling="no" frameborder="no" src="https://player.twitch.tv/?channel=<?= $twitch_match[1] ?>&autoplay=false"></iframe>
                    </div>

                <?php
                /* Check if url is Youtube */
                elseif(preg_match('/^(?:https?:\/\/)?(?:www\.)?(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=))((?:\w|-){11})(?:&list=(\S+))?$/', $link->url, $youtube_match)):
                ?>

                    <div class="m-3">
                        <iframe width="100%" height="350" scrolling="no" frameborder="no" src="https://www.youtube.com/embed/<?= $youtube_match[1] ?>"></iframe>
                    </div>

                <?php
                /* Check if the url is soundcloud */
                elseif(preg_match('/(soundcloud\.com)/', $link->url)):
                ?>

                    <div class="m-3">
                        <iframe width="100%" height="166" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=<?= $link->url ?>"></iframe>
                    </div>

                <?php else: ?>

                    <?php
                    $link_url = empty($link->short_url) ? $settings->url . 'out/' . $link->link_id . '/' . Security::csrf_get_session_token('url_token') : $link->short_url;
                    ?>

                    <div class="my-4">
                        <a href="<?= $link_url ?>" class="btn btn-dark btn-block profile-button-addition" <?= (($settings->store_pro_features_colored && $profile_account->pro) || !$settings->store_pro_features_colored) && !empty($link->color) ? 'style="background: ' . $link->color . '"' : 'style="background: black"' ?>><?= $link->title ?></a>
                    </div>

                <?php endif ?>

            <?php endwhile ?>




        </div>
    </div>
</div>
