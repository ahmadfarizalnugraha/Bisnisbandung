<?php defined('ROOT') || die() ?>
<div class="card card-shadow">
    <div class="card-body">

        <div class="d-flex justify-content-between">
            <h4><?= $language->account_settings->header ?></h4>

            <small class="text-muted"><?= $language->account_settings->display->last_activity ?> <?= (new \DateTime($account->last_activity))->format($language->global->date->datetime_format . ' H:i:s') ?></small>
        </div>


        <form action="" method="post" role="form" enctype="multipart/form-data">

            <input type="hidden" name="form_token" value="<?= Security::csrf_get_session_token('form_token') ?>" />

            <div class="row">
                <div class="col-md-3">
                    <div class="form-group">
                        <label data-toggle="tooltip" title="<?= $language->account_settings->input->avatar ?>">
                            <img src="<?= User::display_image(AVATARS_THUMBS_ROUTE . $account->avatar) ?>" class="rounded-circle profile-settings-avatar" alt="Avatar" />
                            <input id="avatar-file-input" type="file" name="avatar" class="form-control" style="display:none;"/>
                        </label>
                        <p id="avatar-file-status" class="text-muted" style="display: none;"><?= $language->account_settings->input->avatar_selected ?></p>
                        <div>
                            <small class="text-muted"><?= $language->account_settings->input->avatar_help ?></small>
                        </div>
                    </div>
                </div>

                <div class="col-md-9">
                    <div class="form-group">
                        <label><?= $language->account_settings->input->username ?></label>
                        <input type="text" name="username" class="form-control" value="<?= $account->username ?>" tabindex="1" />
                    </div>

                    <div class="form-group">
                        <label><?= $language->account_settings->input->name ?></label>
                        <input type="text" name="name" class="form-control" value="<?= $account->name ?>" tabindex="2" />
                    </div>

                    <div class="form-group">
                        <label><?= $language->account_settings->input->email ?></label>
                        <input type="text" name="email" class="form-control" value="<?= $account->email ?>" tabindex="3" />
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label><?= $language->account_settings->input->description ?></label>
                <input type="text" name="description" class="form-control" value="<?= $account->description ?>" tabindex="4" />
            </div>

            <?php if(($settings->store_pro_features_background && $account->pro) || !$settings->store_pro_features_background): ?>
                <div class="form-group">
                    <label><i class="fa fa-fill-drip"></i> <?= $language->account_settings->input->background ?></label>
                    <input type="file" name="background" class="form-control" />
                    <small class="text-muted"><?= $language->account_settings->input->background_help ?></small>

                    <?php if(!empty($account->background)): ?>
                    <small class="text-muted"><a href="account-settings/background-remove/<?= Security::csrf_get_session_token('url_token') ?>"><?= $language->account_settings->input->background_remove ?></a></small>
                    <?php endif ?>
                </div>
            <?php endif ?>

            <?php if(($settings->store_pro_features_bitly && $account->pro) || !$settings->store_pro_features_bitly): ?>
            <div class="form-group">
                <label><img src="template/images/bitly.svg" class="bitly-logo m-0" /> <?= $language->account_settings->input->bitly_token ?></label>
                <input type="text" name="bitly_token" class="form-control" value="<?= $account->bitly_token ?>" tabindex="5" />
                <small class="text-muted"><?= $language->account_settings->input->bitly_token_help ?></small>
            </div>
            <?php endif ?>

            <?php if(($settings->store_pro_features_fb_pixel && $account->pro) || !$settings->store_pro_features_fb_pixel): ?>
                <div class="form-group">
                    <label><i class="fab fa-facebook"></i> <?= $language->account_settings->input->fb_pixel ?></label>
                    <input type="text" name="fb_pixel" class="form-control" value="<?= $account->fb_pixel ?>" tabindex="6" />
                    <small class="text-muted"><?= $language->account_settings->input->fb_pixel_help ?></small>
                </div>
            <?php endif ?>

            <?php if(($settings->store_pro_features_ga && $account->pro) || !$settings->store_pro_features_ga): ?>
                <div class="form-group">
                    <label><i class="fab fa-google"></i> <?= $language->account_settings->input->ga ?></label>
                    <input type="text" name="ga" class="form-control" value="<?= $account->ga ?>" tabindex="7" />
                    <small class="text-muted"><?= $language->account_settings->input->ga_help ?></small>
                </div>
            <?php endif ?>
            <hr class="my-4"/>

            <h5><?= $language->account_settings->header2 ?></h5>
            <small class="text-muted"><?= $language->account_settings->header2_help ?></small>

            <div class="form-group">
                <label><?= $language->account_settings->input->current_password ?></label>
                <input type="password" name="old_password" class="form-control" tabindex="8" />
            </div>

            <div class="form-group">
                <label><?= $language->account_settings->input->new_password ?></label>
                <input type="password" name="new_password" class="form-control" tabindex="9" />
            </div>

            <div class="form-group">
                <label><?= $language->account_settings->input->repeat_password ?></label>
                <input type="password" name="repeat_password" class="form-control" tabindex="10" />
            </div>

            <div class="form-group text-center">
                <button type="submit" name="submit" class="btn btn-dark" tabindex="8"><?= $language->global->submit_button ?></button>
            </div>

        </form>

    </div>
</div>


<div class="card card-shadow mt-3">
    <div class="card-body">

        <h5><?= $language->account_settings->header3 ?></h5>

        <div class="d-flex justify-content-between align-items-center">
            <small class="text-muted"><?= $language->account_settings->header3_help ?></small>

            <a href="account_settings/delete/<?=  Security::csrf_get_session_token('url_token') ?>" class="btn btn-sm btn-danger" data-confirm="<?= $language->global->info_message->confirm_delete ?>"><?= $language->global->delete ?></a>

        </div>
    </div>
</div>

<script>
    $(document).ready(() => {
        $('#avatar-file-input').on('change', () => {
            $('#avatar-file-status').fadeIn('fast');

            $('[data-toggle="tooltip"]').tooltip();
        });

        $('#avatar-file-remove').on('click', () => {
            $('#avatar-file-input').replaceWith($('#avatar-file-input').val('').clone(true));
            $('#avatar-file-status').fadeOut('fast');
        });
    });
</script>



