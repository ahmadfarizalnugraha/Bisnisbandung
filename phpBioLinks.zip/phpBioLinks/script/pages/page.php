<?php defined('ROOT') || die() ?>

<div class="card card-shadow">
    <div class="card-body">

        <h3><?= $custom_page->title ?></h3>

        <?= $custom_page->description ?>
    </div>
</div>
