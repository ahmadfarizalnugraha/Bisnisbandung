<?php
defined('ROOT') || die();

$link_id = (isset($parameters[0])) ? (int) $parameters[0] : false;
$url_token = (isset($parameters[1])) ?  $parameters[1] : false;

$link = Database::simple_get('url', 'links', ['link_id' => $link_id]);

/* Error chcekcs */
if(!$link_id || !$link || ($url_token && !Security::csrf_check_session_token('url_token', $url_token))) {
    redirect();
}


/* Some needed vars */
$ip = $_SERVER['REMOTE_ADDR'];
$hit_timing = 1;

$hit = $database->query("SELECT `date` FROM `hits` WHERE `ip` = '{$ip}' AND `link_id` = '{$link_id}' ORDER BY `id` DESC")->fetch_object();

/* Insert hit into database if no errors */
if(!$hit || ($hit && (new \DateTime())->modify('-'.$hit_timing.' hours') > (new \DateTime($hit->date)))) {

    $user_id = Database::simple_get('user_id', 'links', ['link_id' => $link_id]);
    $database->query("INSERT INTO `hits` (`link_id`, `date`, `ip`, `user_id`) VALUES ('{$link_id}', '{$date}', '{$ip}', '{$user_id}')");
    $database->query("UPDATE `links` SET `hits` = `hits` + 1 WHERE `link_id` = {$link_id}");

}

/* Redirect */
Header('Location: ' . $link);

