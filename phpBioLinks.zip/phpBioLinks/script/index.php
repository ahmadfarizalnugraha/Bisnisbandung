<?php
include 'core/init.php';
include TEMPLATE_ROUTE . $route . 'overall_header.php';

include PAGES_ROUTE . $route . $page . '.php';

include TEMPLATE_ROUTE . $route . 'overall_footer.php';
include 'core/deinit.php';

