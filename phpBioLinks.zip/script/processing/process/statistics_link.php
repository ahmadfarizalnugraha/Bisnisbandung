<?php
include '../../core/init.php';
User::check_permission(0);

$link_id = isset($_GET['link_id']) ? (int) $_GET['link_id'] : false;
$url_token = isset($_GET['url_token']) ? $_GET['url_token'] : false;

/* Custom Date from the selector */
$date_start = isset($_GET['date_start']) ? $_GET['date_start'] : false;
$date_end = isset($_GET['date_end']) ? $_GET['date_end'] : false;
$date_string = ($date_start && $date_end && validate_date($date_start, 'Y-m-d') && validate_date($date_end, 'Y-m-d')) ? $date_start . ',' . $date_end : false;

/* Default 30 days */
if(!$date_string) {
    $date_start = (new DateTime())->modify('-30 days')->format('Y-m-d H:i:s');
    $date_end = (new DateTime())->format('Y-m-d H:i:s');
}

/* Security checks and validations */
if(
    !empty($_GET)
    && $link_id && $url_token
    && Security::csrf_check_session_token('url_token', $url_token)
    && Database::simple_get('link_id', 'links', ['link_id' => $link_id, 'user_id' => $account_user_id])
) {

    /* Get last 30 days statistics for this link */
    $result = $database->query("
      SELECT 
        COUNT(*) AS `hits`, 
        DATE_FORMAT(`date`, '%Y-%m-%d') AS `formatted_date`
      FROM 
        `hits` 
      WHERE 
        `link_id` = {$link_id}
        AND `date` BETWEEN '{$date_start}' AND DATE_ADD('{$date_end}', INTERVAL 1 DAY)
      GROUP BY
        `formatted_date`
    ");

    $details = [
        'labels' => [],
        'hits' => [],
    ];

    while($day = $result->fetch_object()) {
        $details['labels'][] = $day->formatted_date;
        $details['hits'][] = $day->hits;
    }

    if($language->direction == 'rtl') {
        $details['labels'] = array_reverse($details['labels']);
        $details['hits'] = array_reverse($details['hits']);
    }

    Response::json('', 'success', $details);
}