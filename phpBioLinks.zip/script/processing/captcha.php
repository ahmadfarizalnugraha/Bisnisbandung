<?php
defined('ROOT') || die();

include '../core/classes/Captcha.php';

$captcha = new Captcha;

$captcha->process();
