<?php
include '../../core/init.php';
Security::csrf_page_protection_check('dynamic', false);

$datatable = new DataTable();
$datatable->set_accepted_columns(['username', 'title', 'url', 'hits', 'date']);
$datatable->process($_POST);

$result = $database->query("
    SELECT 
		`links` . *, `users` . `username`, `users` . `user_id`, `users` . `type` AS `user_type`,
		(SELECT COUNT(*) FROM `links`) AS `total_before_filter`,
		(SELECT COUNT(*) FROM `links` LEFT JOIN `users` ON `links` . `user_id` = `users` . `user_id` WHERE `users` . `username` LIKE '%{$datatable->get_search()}%' OR `users` . `name` LIKE '%{$datatable->get_search()}%' OR `links` . `title` LIKE '%{$datatable->get_search()}%' OR `users` . `email` LIKE '%{$datatable->get_search()}%')  AS `total_after_filter`
	FROM 
		`links`
	LEFT JOIN
		`users` ON `links` . `user_id` = `users` . `user_id`
	WHERE 
		`users` . `username` LIKE '%{$datatable->get_search()}%' 
		OR `users` . `name` LIKE '%{$datatable->get_search()}%'
        OR `links` . `title` LIKE '%{$datatable->get_search()}%'
		OR `users` . `email` LIKE '%{$datatable->get_search()}%'
	ORDER BY 
        " . $datatable->get_order() . "
	LIMIT
		{$datatable->get_start()}, {$datatable->get_length()}	
");

$total_before_filter = 0;
$total_after_filter = 0;

$data = [];

while($entry = $result->fetch_object()):

    $username_extra = $entry->user_type > 0 ? ' <span class="text-muted" data-toggle="tooltip" title="' . $language->admin_users_management->tooltip->admin .'"><i class="fa fa-bookmark fa-sm"></i></span>' : '';
    $entry->username = '<a href="' . $settings->url . 'admin/user-edit/' . $entry->user_id . '"> ' . $entry->username . '</a>' . $username_extra;
    $entry->date = '<span data-toggle="tooltip" title="' . $entry->date . '">' . (new DateTime($entry->date))->format($language->global->date->datetime_format) . '</span>';
    $entry->actions = User::admin_generate_buttons('link', $entry->link_id);
    $entry->url = '<a href="' . $entry->url . '" target="_blank">' . $language->admin_links_management->display->url . '</a>';

    $title_extra = !empty($entry->color) ? '<span class="round-shape" data-toggle="tooltip" data-title="' . $entry->color . '" style="background-color:' . $entry->color . '"></span> &nbsp;' : null;
    $title_extra .= !empty($entry->short_url) ? '<img src="template/images/bitly.svg" class="bitly-logo" data-toggle="tooltip" title="' . $language->dashboard->display->bitly_url . '" /> &nbsp;' : null;
    $title_extra .= !empty($entry->start_date) && !empty($entry->end_date) ? '<span data-toggle="tooltip" title="' . sprintf($language->admin_links_management->display->schedule, (new \DateTime($entry->start_date))->format($language->global->date->datetime_format . ' H:i:s') , (new \DateTime($entry->end_date))->format($language->global->date->datetime_format . ' H:i:s')) . '"><i class="fa fa-clock"></i></span>&nbsp;' : null;

    /* Determine if the link expired */
    $entry->expired = !empty($entry->start_date) && !empty($entry->end_date) && (new DateTime($entry->end_date)) < (new DateTime());

    /* Wrap around if expired */
    if($entry->expired) {
        $entry->title = '<s data-toggle="tooltip" title="' . $language->admin_links_management->display->schedule_expired . '">' . $entry->title . '</s>';
    }

    $entry->title =  '<div class="d-flex">' . $title_extra . $entry->title . '</div>';


    $data[] = $entry;
    $total_before_filter = $entry->total_before_filter;
    $total_after_filter = $entry->total_after_filter;
endwhile;


Response::simple_json([
    'data' => $data,
    'draw' => $datatable->get_draw(),
    'recordsTotal' => $total_before_filter,
    'recordsFiltered' =>  $total_after_filter
]);
