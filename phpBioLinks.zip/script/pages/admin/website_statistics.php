<?php
defined('ROOT') || die();
User::check_permission(1);

$date_start = (new DateTime())->modify('-30 day')->format('Y-m-d');
$date_end = (new DateTime())->format('Y-m-d');
$sales_data = $database->query("SELECT SUM(`amount`) AS `earnings`, `currency`, COUNT(`id`) AS `count` FROM `payments` GROUP BY `currency` ");
?>

<div class="card card-shadow mb-5">
    <div class="card-body">
        <h4 class="card-title"><i class="fa fa-dollar-sign"></i> Your website's generated sales</h4>

        <?php if(!$sales_data->num_rows): ?>
            You don't have any sales yet. Keep on going!
        <?php else: ?>


            <?php
            $logs = [];
            $data = $database->query("SELECT COUNT(*) AS `total_sales`, DATE_FORMAT(`date`, '%Y-%m-%d') AS `formatted_date`, TRUNCATE(SUM(`amount`), 2) AS `total_earned` FROM `payments` WHERE `date` BETWEEN '{$date_start}' AND DATE_ADD('{$date_end}', INTERVAL 1 DAY) GROUP BY `formatted_date`");
            while($log = $data->fetch_assoc()) { $logs[] = $log; }

            $chart_labels_array = [];
            $chart_total_earned_array = $chart_total_sales_array = [];

            for($i = 0; $i < count($logs); $i++) {
                $chart_labels_array[] = (new \DateTime($logs[$i]['formatted_date']))->format($language->global->date->datetime_format);
                $chart_total_earned_array[] = $logs[$i]['total_earned'];
                $chart_total_sales_array[] = $logs[$i]['total_sales'];
            }

            if($language->direction == 'rtl') {
                $chart_labels_array = array_reverse($chart_labels_array);
                $chart_total_earned_array = array_reverse($chart_total_earned_array);
                $chart_total_sales_array = array_reverse($chart_total_sales_array);
            }

            /* Defining the chart data */
            $chart_labels = '["' . implode('", "', $chart_labels_array) . '"]';
            $chart_total_earned = '[' . implode(', ', $chart_total_earned_array) . ']';
            $chart_total_sales = '[' . implode(', ', $chart_total_sales_array) . ']';

            ?>

            <?php while($sales = $sales_data->fetch_object()): ?>
                <h6 class="text-muted"><span class="text-info">Total <?= $sales->count ?></span> sales and generated a revenue of <span class="text-success"><?= number_format($sales->earnings, 2) ?></span> <?= $sales->currency ?></h6>
            <?php endwhile ?>

            <div class="chart-container">
                <canvas id="days_sales"></canvas>
            </div>

        <?php endif ?>
    </div>
</div>

<script>
    /* Display chart */
    new Chart(document.getElementById('days_sales').getContext('2d'), {
        type: 'line',
        data: {
            labels: <?= $chart_labels ?>,
            datasets: [{
                label: 'Total Sales',
                data: <?= $chart_total_sales ?>,
                backgroundColor: '#237f52',
                borderColor: '#237f52',
                fill: false
            },
                {
                    label: 'Total Earned',
                    data: <?= $chart_total_earned ?>,
                    backgroundColor: '#37D28D',
                    borderColor: '#37D28D',
                    fill: false
                }]
        },
        options: {
            tooltips: {
                mode: 'index',
                intersect: false
            },
            title: {
                text: 'Last 30 Days Sales Chart',
                display: true
            },
            scales: {
                yAxes: [{
                    ticks: {
                        min: 0
                    }
                }]
            },
            responsive: true,
            maintainAspectRatio: false
        }
    });
</script>

<?php
$data = $database->query("
		SELECT
			(SELECT COUNT(*) FROM `users`) AS `users_count`,
			(SELECT COUNT(*) FROM `payments`) AS `payments_count`,
            (SELECT COUNT(*) FROM `links`) AS `links_count`
		")->fetch_object();
?>

<div class="card card-shadow mb-5">
    <div class="card-body">
        <h4 class="card-title">Here are some total numbers</h4>

        <div class="chart-container">
            <canvas id="total_chart"></canvas>
        </div>

    </div>
</div>


<script>
    /* Display chart */
    let total_chart_id = document.getElementById('total_chart').getContext('2d');

    let total_chart = new Chart(total_chart_id, {
        type: 'bar',
        data: {
            labels: ['Users', 'Payments', 'Links'],
            datasets: [{
                label: 'Totals',
                data: [<?= $data->users_count ?>, <?= $data->payments_count ?>, <?= $data->links_count ?>],
                backgroundColor: ['#007bff', '#37d28d', '#f75581'],
                borderWidth: 1
            }]
        },
        options: {
            title: {
                text: '',
                display: false
            },
            scales: {
                yAxes: [{
                    ticks: {
                        min: 0
                    }
                }]
            },
            responsive: true,
            maintainAspectRatio: false
        }
    });
</script>





<?php
$data = $database->query("
		SELECT
			(SELECT COUNT(*) FROM `users` WHERE YEAR(`date`) = YEAR(CURDATE()) AND MONTH(`date`) = MONTH(CURDATE())) AS `users_count`,
			(SELECT COUNT(*) FROM `payments` WHERE YEAR(`date`) = YEAR(CURDATE()) AND MONTH(`date`) = MONTH(CURDATE())) AS `payments_count`,
            (SELECT COUNT(*) FROM `links` WHERE YEAR(`date`) = YEAR(CURDATE()) AND MONTH(`date`) = MONTH(CURDATE())) AS `links_count`
		")->fetch_object();
?>

<div class="card card-shadow mb-5">
    <div class="card-body">
        <h4 class="card-title">This is what happened this month</h4>

        <div class="chart-container">
            <canvas id="month_chart"></canvas>
        </div>

    </div>
</div>


<script>
    /* Display chart */
    let month_chart_id = document.getElementById('month_chart').getContext('2d');

    let month_chart = new Chart(month_chart_id, {
        type: 'bar',
        data: {
            labels: ['Users', 'Payments', 'Links'],
            datasets: [{
                label: 'New stats',
                data: [<?= $data->users_count ?>, <?= $data->payments_count ?>, <?= $data->links_count ?>],
                backgroundColor: ['#007bff', '#37d28d', '#f75581'],
                borderWidth: 1
            }]
        },
        options: {
            title: {
                text: '',
                display: false
            },
            scales: {
                yAxes: [{
                    ticks: {
                        min: 0
                    }
                }]
            },
            responsive: true,
            maintainAspectRatio: false
        }
    });
</script>



<?php
$data = $database->query("
SELECT
(SELECT COUNT(`user_id`) FROM `users` WHERE YEAR(`date`) = YEAR(CURDATE()) AND MONTH(`date`) = MONTH(CURDATE()) AND DAY(`date`) = DAY(CURDATE())) AS `new_users_today`,
(SELECT COUNT(`user_id`) FROM `users` WHERE `active` = '1') AS `confirmed_users`,
(SELECT COUNT(`user_id`) FROM `users` WHERE `active` = '0') AS `unconfirmed_users`,
(SELECT COUNT(`user_id`) FROM `users` WHERE YEAR(`last_activity`) = YEAR(CURDATE()) AND MONTH(`last_activity`) = MONTH(CURDATE())) AS `active_users`
")->fetch_object();
?>


<div class="card card-shadow mb-5">
    <div class="card-body">
        <h4 class="card-title">Some details about registered accounts..</h4>

        <div class="chart-container">
            <canvas id="users_chart"></canvas>
        </div>

    </div>
</div>


<script>
    /* Display chart */
    let users_chart_id = document.getElementById('users_chart').getContext('2d');

    let users_chart = new Chart(users_chart_id, {
        type: 'bar',
        data: {
            labels: ['New users today', 'Total Confirmed Users', 'Total Unconfirmed Users', 'Total active users in last month'],
            datasets: [{
                label: 'Account stats',
                data: [<?= $data->new_users_today ?>, <?= $data->confirmed_users ?>, <?= $data->unconfirmed_users ?>, <?= $data->active_users ?>],
                backgroundColor: ['#714eb7', '#cd476b', '#0064ce', '#2284ba'],
                borderWidth: 1
            }]
        },
        options: {
            title: {
                text: '',
                display: false
            },
            scales: {
                yAxes: [{
                    ticks: {
                        min: 0
                    }
                }]
            },
            responsive: true,
            maintainAspectRatio: false
        }
    });
</script>
