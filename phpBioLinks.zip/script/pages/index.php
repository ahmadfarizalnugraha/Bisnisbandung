<?php
defined('ROOT') || die();

if($settings->facebook_login) {
    /* Facebook Login */
    $facebook = new Facebook\Facebook([
        'app_id' => $settings->facebook_app_id,
        'app_secret' => $settings->facebook_app_secret,
        'default_graph_version' => 'v2.2',
    ]);

    $facebook_login_url = $facebook->getRedirectLoginHelper()->getLoginUrl($settings->url . 'login/facebook', ['email', 'public_profile']);
}

if($settings->instagram_login) {

    $instagram = new MetzWeb\Instagram\Instagram([
        'apiKey'      => $settings->instagram_client_id,
        'apiSecret'   => $settings->instagram_client_secret,
        'apiCallback' => $settings->url . 'login/instagram'
    ]);

    $instagram_login_url = $instagram->getLoginUrl();
}

?>


<div class="index-container" data-aos="fade">
    <div class="container">

        <div class="col">
            <h1 class="index-header-text" data-aos="fade" data-aos-delay="300"><?= $language->index->display->header ?></h1>
            <span class="index-subheader-text lead" data-aos="fade" data-aos-delay="600"><?= sprintf($language->index->display->subheader, $settings->title) ?></span>

            <div class="mt-5" data-aos="fade" data-aos-delay="900">
                <?php if(!User::logged_in()): ?>
                    <a href="register" class="btn btn-lg btn-main border-0 index-header-button"><?= $language->index->button->sign_up ?></a>
                <?php else: ?>
                    <a href="dashboard" class="btn btn-lg btn-main border-0 index-header-button"><i class="fa fa-tags"></i> <?= $language->index->button->dashboard ?></a>
                <?php endif ?>
            </div>
        </div>

    </div>
</div>


<div class="">

    <div class="container">

        <div class="mt-2">
            <?php display_notifications() ?>
        </div>

        <div class="row index-block-margin">
            <div class="col-md-6 text-center">
                <img src="template/images/presentation.png" class="img-fluid zoomer" data-aos="fade-right" style="max-height: 450px;" />
            </div>

            <div class="col-md-6" style="padding-top: 80px">
                <h2><?= $language->index->display->description_header ?></h2>

                <p class="mt-4"><?= sprintf($language->index->display->description, $settings->title) ?></p>

                <div class="mt-4">
                    <div class="btn-group">
                        <?php if(!User::logged_in()): ?>
                            <?php if($settings->facebook_login): ?>
                                <a href="<?= $facebook_login_url ?>" class="btn btn-primary border-0"><?= $language->login->button->facebook ?></a>
                            <?php endif ?>
                            <?php if($settings->instagram_login): ?>
                                <a href="<?= $instagram_login_url ?>" class="btn btn-primary bg-instagram border-0"><?= $language->login->button->instagram ?></a>
                            <?php endif ?>
                        <?php endif ?>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="faded-container">
        <div class="container">

            <div class="row">
                <div class="col-md-4 text-center mb-5 mb-md-0" data-aos="fade-down" data-aos-delay="">
                    <i class="fa fa-3x fa-user mb-3 text-light"></i>

                    <h3 class="font-weight-light text-white"><?= $language->index->display->box1_header ?></h3>

                    <p class="card-small-text mb-0 mt-3 text-white-50"><?= $language->index->display->box1_text ?></p>
                </div>

                <div class="col-md-4 text-center mb-5 mb-md-0" data-aos="fade-down" data-aos-delay="300">
                    <i class="fa fa-3x fa-link mb-3 text-light"></i>

                    <h3 class="font-weight-light text-white"><?= $language->index->display->box2_header ?></h3>

                    <p class="card-small-text mb-0 mt-3 text-white-50"><?= $language->index->display->box2_text ?></p>
                </div>

                <div class="col-md-4 text-center mb-5 mb-md-0" data-aos="fade-down" data-aos-delay="600">
                    <i class="fab fa-3x fa-instagram mb-3 text-light"></i>

                    <h3 class="font-weight-light text-white"><?= $language->index->display->box3_header ?></h3>

                    <p class="card-small-text mb-0 mt-3 text-white-50"><?= $language->index->display->box3_text ?></p>
                </div>
            </div>

        </div>
    </div>

    <div class="container">
        <div class="index-block-margin">
            <div class="text-center">
                <h2 class="h1"><?= $language->index->display->pricing_header ?></h2>
                <p class="lead text-muted"><?= $language->index->display->pricing_text ?></p>
            </div>
        </div>


        <div class="index-block-margin">
            <?php require_once ROOT . TEMPLATE_ROUTE . 'includes/pro.php' ?>
        </div>
        </div>
</div>
