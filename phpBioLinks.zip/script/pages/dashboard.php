<?php defined('ROOT') || die() ?>
<div class="row">
    <div class="col-md-8">
        <div class="card bg-main border-0 text-white mb-3">
            <div class="card-body">
                <h4 class="card-title"><?= $language->dashboard->input->add_new ?></h4>

                <form id="new_link" action="dashboard" method="post" role="form">
                    <input type="hidden" name="form_token" value="<?= Security::csrf_get_session_token('form_token') ?>" />

                    <div class="form-group">
                        <input type="text" class="form-control" name="title" placeholder="<?= $language->dashboard->input->title_placeholder ?>">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" name="url" placeholder="<?= $language->dashboard->input->url_placeholder ?>">
                    </div>

                    <?php if(($settings->store_pro_features_colored && $account->pro) || !$settings->store_pro_features_colored): ?>
                    <div id="color">
                        <div class="form-group">
                            <a href="#" id="add_color" class="btn btn-light btn-block btn-sm"><?= $language->dashboard->input->add_color ?></a>
                        </div>
                    </div>

                    <input type="hidden" name="color" value="#000000">
                    <?php endif ?>

                    <?php if(($settings->store_pro_features_schedule && $account->pro) || !$settings->store_pro_features_schedule): ?>
                        <div id="schedule" class="row" style="display: none;">
                            <div class="col">
                                <div class="form-group">
                                    <input
                                        type="text"
                                        class="form-control"
                                        data-min="<?= str_replace(' ', 'T', $date) ?>"
                                        name="start_date"
                                        value=""
                                        placeholder="<?= $language->dashboard->input->start_date ?>"
                                        autocomplete="off"
                                    >
                                </div>
                            </div>

                            <div class="col">
                                <div class="form-group">
                                    <input
                                        type="text"
                                        class="form-control"
                                        data-min="<?= str_replace(' ', 'T', $date) ?>"
                                        name="end_date"
                                        value=""
                                        placeholder="<?= $language->dashboard->input->end_date ?>"
                                        autocomplete="off"
                                    >
                                </div>
                            </div>
                        </div>
                    <?php endif ?>

                    <?php if(!empty($account->bitly_token) && (($settings->store_pro_features_bitly && $account->pro) || !$settings->store_pro_features_bitly)): ?>
                    <div class="custom-control custom-switch mb-3">
                        <input type="checkbox" class="custom-control-input" id="bitly" name="bitly">
                        <label class="custom-control-label" for="bitly"><img src="template/images/bitly.svg" class="bitly-logo m-0" /> <?= $language->dashboard->input->bitly ?></label>
                    </div>
                    <?php endif ?>

                    <div class="text-center">
                        <?php if(($settings->store_pro_features_schedule && $account->pro) || !$settings->store_pro_features_schedule): ?>
                        <a href="#" id="add_schedule" class="btn btn-light "><i class="fa fa-clock"></i> <?= $language->dashboard->input->schedule_toggle ?></a>
                        <?php endif ?>

                        <button type="submit" name="submit" class="btn btn-default"><?= $language->global->submit_button ?></button>
                    </div>
                </form>
            </div>
        </div>

        <div id="link_preview" class="d-none">
            <span class="btn btn-dark btn-block profile-button-addition" style="background: #000002"></span>
        </div>

        <div id="links">
            <?php while($link = $links_result->fetch_object()): ?>

                <?php

                /* Determine if the link expired */
                $link->expired = !empty($link->start_date) && !empty($link->end_date) && (new DateTime($link->end_date)) < (new DateTime());

                ?>

                <div class="my-3 card-shadow card link zoomer" data-id="<?= $link->link_id ?>">
                    <div class="card-body">

                        <div class="d-flex justify-content-between">
                            <div class="d-flex">
                                <?php if(!empty($link->color)): ?>
                                <span class="round-shape" style="background-color: <?= $link->color ?>"></span>
                                <?php endif ?>
                                <?php if(!empty($link->short_url)): ?>
                                    <img src="template/images/bitly.svg" class="bitly-logo" data-toggle="tooltip" title="<?= $language->dashboard->display->bitly_url ?>" />
                                <?php endif ?>

                                <h5 class="card-title">
                                    <?= $link->expired ? '<s data-toggle="tooltip" title="' . $language->dashboard->display->schedule_expired . '">' : null ?>
                                    <?= $link->title ?>
                                    <?= $link->expired ? '</s>' : null ?>
                                </h5>
                            </div>


                            <div>
                                <a class="badge badge-dark text-white clickable" data-toggle="modal" data-target="#edit_link" data-id="<?= $link->link_id ?>" data-title="<?= $link->title ?>" data-url="<?= $link->url ?>" data-color="<?= $link->color ?>" data-bitly="<?= !empty($link->short_url) ?>" data-start-date="<?= $link->start_date ?>" data-end-date="<?= $link->end_date ?>"><i class="fa fa-pencil-alt"></i></a>
                                <a class="badge badge-dark text-white clickable" data-confirm="<?= $language->global->info_message->confirm_delete ?>" href="dashboard/delete/<?= $link->link_id ?>/<?=  Security::csrf_get_session_token('url_token') ?>"><i class="fa fa-trash"></i></a>
                                <span class="badge badge-dark text-white clickable drag" data-toggle="tooltip" title="<?= $language->dashboard->display->drag ?>"><i class="fa fa-arrows-alt"></i></span>
                            </div>
                        </div>

                        <p class="card-text"><?= $link->url ?></p>

                        <div>
                            <small class="text-muted">
                                <?php printf($language->dashboard->display->total_hits, nr($link->hits)) ?>

                                - <a href="#" class="text-dark" data-toggle="modal" data-target="#statistics_link" data-id="<?= $link->link_id ?>" data-url-token="<?=  Security::csrf_get_session_token('url_token') ?>">
                                    <?= $language->dashboard->display->statistics ?>
                                </a>
                            </small>
                        </div>

                        <?php if(!empty($link->start_date) && !empty($link->end_date)): ?>
                        <div>
                            <small class="text-muted">
                                <i class="fa fa-clock"></i> <?= sprintf($language->dashboard->display->schedule, (new \DateTime($link->start_date))->format($language->global->date->datetime_format . ' H:i:s') , (new \DateTime($link->end_date))->format($language->global->date->datetime_format . ' H:i:s')) ?>
                            </small>
                        </div>
                        <?php endif ?>

                    </div>
                </div>
            <?php endwhile ?>
        </div>

        <input type="hidden" name="form_token" value="<?= Security::csrf_get_session_token('form_token') ?>" />
    </div>

    <div class="col-md-4">
        <div class="card card-shadow">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <h4 class="card-title"><?= $account->name ?></h4>
                    <?php if($account->pro): ?>
                        <span class="align-self-start btn btn-main btn-sm"><i class="fa fa-star"></i> <?= $language->dashboard->sidebar->pro ?></span>
                    <?php else: ?>
                        <a href="pro" class="align-self-start btn btn-light btn-sm"><i class="fa fa-unlock-alt"></i> <?= $language->store->display->go_pro ?></a>
                    <?php endif ?>
                </div>
                <p class="card-text"><?= $language->dashboard->sidebar->link ?> <a href="<?= $settings->url . $account->username ?>" target="_blank">@<?= $account->username ?></a></p>

                <input type="text" class="form-control" name="url" value="<?= $settings->url . $account->username ?>"  onclick="this.select();" />

                <small class="card-text text-muted"><i class="fa fa-arrow-up"></i> <?= $language->dashboard->sidebar->link_help ?></small>
            </div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item"><?php printf($language->dashboard->sidebar->total_links, nr($total_links)) ?></li>
                <li class="list-group-item"><?php printf($language->dashboard->sidebar->total_hits, nr($total_hits)) ?></li>

                <?php if($account->pro): ?>
                    <li class="list-group-item">
                        <?= $language->dashboard->display->pro_account ?>
                        <div><small><?= sprintf($language->dashboard->display->pro_account_help, $pro_days_left) ?></small></div>
                    </li>
                <?php endif ?>
            </ul>
            <div class="card-body">
                <a class="card-link text-dark" href="account-settings"><i class="fa fa-wrench"></i> <?= $language->account_settings->menu ?></a><br />
            </div>
        </div>

        <?php if(($settings->store_pro_features_fb_pixel && $account->pro) || !$settings->store_pro_features_fb_pixel): ?>
        <div class="mt-3 card card-shadow">
            <div class="card-body">
                <?php if(!empty($account->fb_pixel)): ?>
                <span><i class="text-success fa fa-check-circle"></i> <?= $language->dashboard->sidebar->fb_pixel_active ?></span>
                <?php else: ?>
                <span><i class="text-danger fa fa-times"></i> <a href="account-settings" class="text-dark card-link" data-toggle="tooltip" data-title="<?= $language->dashboard->sidebar->fb_pixel_tooltip ?>"><?= $language->dashboard->sidebar->fb_pixel_inactive ?></a></span>
                <?php endif ?>
            </div>
        </div>
        <?php endif ?>

        <?php if(($settings->store_pro_features_bitly && $account->pro) || !$settings->store_pro_features_bitly): ?>
            <div class="mt-3 card card-shadow">
                <div class="card-body">
                    <?php if(!empty($account->bitly_token)): ?>
                        <span><i class="text-success fa fa-check-circle"></i> <?= $language->dashboard->sidebar->bitly_active ?></span>
                    <?php else: ?>
                        <span><i class="text-danger fa fa-times"></i> <a href="account-settings" class="text-dark card-link" data-toggle="tooltip" data-title="<?= $language->dashboard->sidebar->bitly_tooltip ?>"><?= $language->dashboard->sidebar->bitly_inactive ?></a></span>
                    <?php endif ?>
                </div>
            </div>
        <?php endif ?>

    </div>
</div>

<script>
/* Preview button */
let color_handler = () => {
    let title = $('#new_link input[name="title"]').val();

    if(title.trim() != '') {

        if($('#link_preview').hasClass('d-none')) {
            $('#link_preview').hide().removeClass('d-none').fadeIn();
        }

        let $color = $('#new_link input[name="color"]');

        if($color) {
            $('#link_preview span').css('background', $color.val());
        }

        $('#link_preview span').text(title);
    } else {
        $('#link_preview').fadeOut(() => {
            $('#link_preview').addClass('d-none').fadeIn();
        })
    }
};

$('#new_link input[name="title"]').on('keyup change', color_handler);


let sortable = Sortable.create(document.getElementById('links'), {
    animation: 150,
    handle: '.drag',
    onUpdate: () => {

        let form_token = $('input[name="form_token"]').val();

        let links = [];
        $('#links > .link').each((i, elm) => {
            let link = {
                link_id: $(elm).data('id'),
                order: i
            };

            links.push(link);
        });

        $.ajax({
            type: 'POST',
            url: 'processing/process/link_order.php',
            data: {
                data: links,
                form_token
            },
            dataType: 'json'
        });

    }
});

/* Enabling color input */
$('#add_color').on('click', event => {

    $(event.currentTarget).fadeOut('', (elm) => {
        $(elm).remove();

        const new_pickr = Pickr.create({
            el: '#color',

            default: '000000',

            components: {
                preview: true,
                opacity: false,
                hue: true,
                comparison: false,
                interaction: {
                    hex: true,
                    rgba: false,
                    hsla: false,
                    hsva: false,
                    cmyk: false,
                    input: true,
                    clear: false,
                    save: true
                }
            },

            onSave(hsva, instance) {
                $('#new_link input[name="color"]').val(hsva.toHEX().toString());

                color_handler();
            },
        });

    });

    /* Enable tooltips everywhere */
    $('[data-toggle="tooltip"]').tooltip();

    event.preventDefault();

});

/* Enabling schedule input */
$('#add_schedule').on('click', event => {

    $(event.currentTarget).fadeOut('', (elm) => {
        $(elm).remove();

        /* Display the hidden inputs */
        $('#schedule').fadeIn();

    });

    /* Enable tooltips everywhere */
    $('[data-toggle="tooltip"]').tooltip();

    event.preventDefault();

});

$(document).ready(() => {
    /* Initiate the datepicker */
    $('[name="start_date"],[name="end_date"]').datepicker({
        classes: 'datepicker-modal',
        language: 'en',
        dateFormat: 'yyyy-mm-dd',
        timeFormat: 'hh:ii:00',
        autoClose: true,
        timepicker: true,
        toggleSelected: false,
        minDate: new Date($('[name="start_date"]').data('min')),
    });
});


</script>
