<?php
defined('ROOT') || die();

User::logout();
