<?php defined('ROOT') || die() ?>

        </div>

        <?php if(!$profile_account->pro): ?>
        <div class="sticky-footer">
            <div class="container text-center">

                <span class="text-muted"><?= 'Copyright &copy; ' . date('Y') . ' <a href="' . $settings->url . '">' . $settings->title . '</a>. All rights reserved.' ?></span>

            </div>
        </div>
        <?php endif ?>

        <script src="template/js/jquery-3.2.1.min.js"></script>
        <script src="template/js/popper.min.js"></script>
        <script src="template/js/bootstrap.min.js"></script>

        <script>
            $(document).ready(function() {
                /* Enable tooltips everywhere */
                $('[data-toggle="tooltip"]').tooltip()
            });
        </script>
    </body>
</html>
